"""Unit tests for AstraGrid Mission Debt Ledger."""

import pytest
from astragrid.models import DeadlineType, Task, TaskStatus
from astragrid.tasks.debt_ledger import MissionDebtLedger


def test_task_completion_and_immutability():
    """Verify task completes when duration met, and terminal state cannot be altered."""
    task = Task(
        id="sample_task",
        name="Sample Task",
        power_kw=2.0,
        duration_hours=1.0,
        release_hour=0.0,
        deadline_hour=5.0,
    )
    ledger = MissionDebtLedger([task])

    # Advance 1.0 hour
    is_done, evt = ledger.update_task_progress("sample_task", 1.0)
    assert is_done is True
    assert task.status == TaskStatus.COMPLETED
    assert task.is_terminal is True

    # Further progress does nothing
    is_done_again, _ = ledger.update_task_progress("sample_task", 1.0)
    assert is_done_again is False
    assert task.completed_hours == 1.0


def test_deferral_and_recovery():
    """Verify task deferral records history, increment counts, and allows recovery."""
    task = Task(
        id="flexible_task",
        name="Flexible Task",
        power_kw=3.0,
        duration_hours=2.0,
        release_hour=1.0,
        deadline_hour=10.0,
    )
    ledger = MissionDebtLedger([task])

    # Record deferral
    evt = ledger.record_deferral("flexible_task", step=4, time_hours=1.0, reason="Solar deficit", policy_decision="Reserve Protection")
    assert evt is not None
    assert task.status == TaskStatus.DEFERRED
    assert task.deferral_count == 1
    assert len(task.deferral_history) == 1
    assert ledger.deferred_task_count == 1
    assert ledger.total_mission_debt_kwh == 6.0  # 3 kW * 2h

    # Record recovery
    rec_evt = ledger.record_recovery("flexible_task", step=8, time_hours=2.0, reason="Solar surplus available")
    assert rec_evt is not None
    assert task.status == TaskStatus.SCHEDULED
    assert task.recovery_count == 1


def test_hard_deadline_infeasibility_detection():
    """Verify hard deadline infeasibility is surfaced without relaxing deadline."""
    task = Task(
        id="critical_science",
        name="Critical Science",
        power_kw=5.0,
        duration_hours=4.0,
        release_hour=1.0,
        deadline_hour=4.0,  # Deadline at t=4.0
        deadline_type=DeadlineType.HARD,
    )
    ledger = MissionDebtLedger([task])

    # At t=2.0, remaining duration is 4.0h, but time left until deadline is only 2.0h!
    events = ledger.check_deadlines_and_feasibility(current_time_hours=2.0, step=8)

    assert task.status == TaskStatus.INFEASIBLE_BY_DEADLINE
    infeas_events = [e for e in events if e.code == "TASK_INFEASIBLE_BY_DEADLINE"]
    assert len(infeas_events) == 1
    # Deadline must NOT be altered
    assert task.deadline_hour == 4.0


def test_dynamic_task_addition_and_energy_calculation():
    """Verify dynamically added task computes expected energy correctly and updates ledger."""
    ledger = MissionDebtLedger()
    new_task = Task(
        id="drill_exp_01",
        name="Regolith Deep Core Drill",
        power_kw=4.5,
        duration_hours=2.0,
        release_hour=0.0,
        deadline_hour=12.0,
        deadline_type=DeadlineType.HARD,
        priority=1,
    )

    # Expected Energy = Power * Duration = 4.5 * 2.0 = 9.0 kWh
    assert new_task.remaining_energy_kwh == 9.0

    evt = ledger.add_task(new_task, step=2, time_hours=0.5)
    assert evt is not None
    assert evt.code == "TASK_ADDED"
    assert evt.details["expected_energy_kwh"] == 9.0
    assert ledger.get_task("drill_exp_01") is not None
    assert len(ledger.all_tasks()) == 1

