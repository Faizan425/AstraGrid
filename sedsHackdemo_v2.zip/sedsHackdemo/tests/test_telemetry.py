"""Unit tests for AstraGrid telemetry generation and state estimation."""

import pytest
from astragrid.config import HabitatConfig
from astragrid.faults.models import Fault
from astragrid.models import FaultCategory, TelemetryObservation
from astragrid.telemetry.estimator import StateEstimator
from astragrid.telemetry.sensors import TelemetryGenerator


def test_byzantine_sensor_isolation():
    """Verify state estimator isolates an arbitrary Byzantine sensor among three independent readings."""
    cfg = HabitatConfig()
    estimator = StateEstimator(cfg, outlier_threshold=0.12)

    # Observation where sensor_2 is corrupted to 0.75, while sensors 1 and 3 read ~0.20
    obs = TelemetryObservation(
        step=16,
        time_hours=4.0,
        soc_readings={"sensor_1": 0.21, "sensor_2": 0.75, "sensor_3": 0.19},
        temp_c=21.0,
        solar_kw=10.0,
        total_load_kw=7.0,
        battery_net_power_kw=-2.0,
    )

    est, events = estimator.estimate_state(obs, prior_estimate=None, commanded_battery_kw=0.0)

    # Sensor 2 should be flagged and isolated
    assert "sensor_2" in est.suspect_sensor_ids
    assert "sensor_2" in estimator.isolated_sensors
    # Consensus should reject 0.75 and average sensors 1 and 3 (~0.20)
    assert est.estimated_soc == pytest.approx(0.20, abs=0.02)
    assert est.soc_confidence == 0.85

    # Check structured event emitted
    isolated_events = [e for e in events if e.code == "SENSOR_OUTLIER_ISOLATED"]
    assert len(isolated_events) == 1
    assert isolated_events[0].details["isolated_sensor"] == "sensor_2"


def test_estimator_interface_has_no_true_state_access():
    """Verify StateEstimator interface accepts only TelemetryObservation and never TruePhysicalState."""
    import inspect
    sig = inspect.signature(StateEstimator.estimate_state)
    params = list(sig.parameters.keys())
    assert "true_state" not in params
    assert "observation" in params


def test_widespread_conflict_reduces_confidence():
    """Verify that if multiple sensors disagree unpredictably, confidence drops."""
    cfg = HabitatConfig()
    estimator = StateEstimator(cfg, outlier_threshold=0.12)

    # All three sensors disagree by huge margins
    obs = TelemetryObservation(
        step=20,
        time_hours=5.0,
        soc_readings={"sensor_1": 0.10, "sensor_2": 0.50, "sensor_3": 0.90},
        temp_c=21.0,
        solar_kw=5.0,
        total_load_kw=7.0,
        battery_net_power_kw=0.0,
    )

    est, events = estimator.estimate_state(obs, prior_estimate=None, commanded_battery_kw=0.0)
    assert est.soc_confidence <= 0.40
    conflict_events = [e for e in events if e.code == "SENSOR_CONSENSUS_FAILURE"]
    assert len(conflict_events) == 1
