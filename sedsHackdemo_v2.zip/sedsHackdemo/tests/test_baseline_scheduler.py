"""Unit tests for BaselinePriorityScheduler and PlanValidator."""

import pytest
from astragrid.config import HabitatConfig
from astragrid.control.baseline import BaselinePriorityScheduler
from astragrid.control.plan_validator import PlanValidator
from astragrid.models import (
    ControllerAction,
    DeadlineType,
    LimitingFactor,
    OperatingMode,
    StateEstimate,
    SurvivalHorizon,
    Task,
)
from astragrid.tasks.debt_ledger import MissionDebtLedger


def test_baseline_preserves_essential_loads_during_solar_deficit():
    """Verify baseline controller discharges battery to support essential loads and defers flexible tasks."""
    cfg = HabitatConfig()
    scheduler = BaselinePriorityScheduler(cfg)

    # 1 task eligible
    task = Task(
        id="science_exp",
        name="Science Exp",
        power_kw=4.0,
        duration_hours=2.0,
        release_hour=0.0,
        deadline_hour=10.0,
    )
    ledger = MissionDebtLedger([task])

    # Night state: 0 kW solar, 70% battery SOC
    est = StateEstimate(
        step=4,
        time_hours=1.0,
        estimated_soc=0.70,
        soc_confidence=1.0,
        suspect_sensor_ids=[],
        estimated_battery_kwh=70.0,
        estimated_temp_c=21.0,
        estimated_solar_kw=0.0,
        estimated_load_kw=7.0,
    )

    survival = SurvivalHorizon(hours=10.0, steps=40, limiting_factor=LimitingFactor.ENERGY_RESERVE, assumptions="Test")
    action, events = scheduler.plan_step(4, 1.0, est, ledger, OperatingMode.NORMAL, survival)

    # Battery must discharge (negative power) to cover essential load
    assert action.target_battery_power_kw < 0
    # Task must be deferred, not scheduled
    assert "science_exp" in action.deferred_task_ids
    assert "science_exp" not in action.scheduled_task_ids
    assert action.reason_code == "SOLAR_DEFICIT"


def test_baseline_charges_battery_and_schedules_tasks_in_surplus():
    """Verify baseline controller utilizes solar surplus for both battery charging and mission tasks."""
    cfg = HabitatConfig()
    scheduler = BaselinePriorityScheduler(cfg)

    task = Task(
        id="rover_charge",
        name="Rover Charge",
        power_kw=4.0,
        duration_hours=2.0,
        release_hour=0.0,
        deadline_hour=10.0,
    )
    ledger = MissionDebtLedger([task])

    # Midday state: 25 kW solar, 80% SOC
    est = StateEstimate(
        step=40,
        time_hours=10.0,
        estimated_soc=0.80,
        soc_confidence=1.0,
        suspect_sensor_ids=[],
        estimated_battery_kwh=80.0,
        estimated_temp_c=21.0,
        estimated_solar_kw=25.0,
        estimated_load_kw=7.0,
    )

    survival = SurvivalHorizon(hours=24.0, steps=96, limiting_factor=LimitingFactor.NONE_WITHIN_HORIZON, assumptions="Test")
    action, events = scheduler.plan_step(40, 10.0, est, ledger, OperatingMode.NORMAL, survival)

    # Surplus available -> Task scheduled
    assert "rover_charge" in action.scheduled_task_ids
    # Battery charging
    assert action.target_battery_power_kw > 0


def test_plan_validator_rejects_invalid_actions():
    """Verify PlanValidator catches rate limit violations and does not mutate values."""
    cfg = HabitatConfig()
    validator = PlanValidator(cfg)

    est = StateEstimate(
        step=0,
        time_hours=0.0,
        estimated_soc=0.50,
        soc_confidence=1.0,
        suspect_sensor_ids=[],
        estimated_battery_kwh=50.0,
        estimated_temp_c=21.0,
        estimated_solar_kw=10.0,
        estimated_load_kw=7.0,
    )

    # Excessive discharge rate (50 kW > max 30 kW)
    invalid_action = ControllerAction(
        scheduled_task_ids=[],
        deferred_task_ids=[],
        heater_power_kw=0.0,
        curtailed_solar_kw=0.0,
        shed_essential_load_kw=0.0,
        target_battery_power_kw=-50.0,
        operating_mode=OperatingMode.NORMAL,
        reason_code="TEST",
        explanation="Test",
    )

    is_valid, errors = validator.validate_action(invalid_action, est)
    assert is_valid is False
    assert any("exceeds maximum" in err for err in errors)
    # Ensure value was not mutated
    assert invalid_action.target_battery_power_kw == -50.0
