"""Unit tests for AstraGrid habitat physical simulator."""

import pytest
from astragrid.config import HabitatConfig, SimulationConfig
from astragrid.faults.models import Fault
from astragrid.models import FaultCategory, Task
from astragrid.simulator.engine import HabitatSimulator


def test_initial_state_and_units():
    """Verify initial physical state is correctly populated with units (kW, kWh, °C)."""
    cfg = HabitatConfig()
    sim = HabitatSimulator(cfg)
    st = sim.true_state

    assert st.step == 0
    assert st.time_hours == 0.0
    assert st.true_soc == 0.85
    assert st.battery_energy_kwh == pytest.approx(85.0, abs=0.1)
    assert st.habitat_temp_c == 21.0
    assert st.usable_capacity_kwh == 100.0


def test_battery_charge_and_discharge_bounds():
    """Verify battery stays strictly within [0, usable_capacity] and obeys charge/discharge power limits."""
    cfg = HabitatConfig()
    sim = HabitatSimulator(cfg)

    # 1. Overcharge attempt
    for _ in range(20):
        sim.step(commanded_battery_kw=50.0, heater_power_kw=0.0, active_tasks=[])
    
    assert sim.true_state.battery_energy_kwh <= cfg.battery.usable_capacity_kwh + 1e-4
    assert sim.true_state.true_soc <= 1.0

    # 2. Complete discharge attempt
    for _ in range(50):
        sim.step(commanded_battery_kw=-50.0, heater_power_kw=0.0, active_tasks=[])

    assert sim.true_state.battery_energy_kwh >= 0.0
    assert sim.true_state.true_soc >= 0.0


def test_no_simultaneous_charge_and_discharge():
    """Verify battery never charges and discharges simultaneously."""
    cfg = HabitatConfig()
    sim = HabitatSimulator(cfg)

    st_charge = sim.step(commanded_battery_kw=15.0, heater_power_kw=0.0, active_tasks=[])
    assert st_charge.battery_power_kw > 0  # Charging only

    st_discharge = sim.step(commanded_battery_kw=-15.0, heater_power_kw=0.0, active_tasks=[])
    assert st_discharge.battery_power_kw < 0  # Discharging only


def test_thermal_model_dynamics():
    """Verify one-zone thermal model updates correctly using heat balance equation."""
    cfg = HabitatConfig()
    sim = HabitatSimulator(cfg)
    initial_temp = sim.true_state.habitat_temp_c

    # With zero heater and cold outside (-20°C), temperature should decrease over time
    for _ in range(10):
        sim.step(commanded_battery_kw=0.0, heater_power_kw=0.0, active_tasks=[])
    
    assert sim.true_state.habitat_temp_c < initial_temp

    # With maximum heater power, temperature should rise
    temp_before_heating = sim.true_state.habitat_temp_c
    for _ in range(10):
        sim.step(commanded_battery_kw=0.0, heater_power_kw=cfg.thermal.heater_max_power_kw, active_tasks=[])

    assert sim.true_state.habitat_temp_c > temp_before_heating


def test_physical_solar_fault_reduces_generation():
    """Verify physical solar damage fault directly reduces true physical solar output."""
    cfg = HabitatConfig()
    sim = HabitatSimulator(cfg)

    # Move to peak hour (step 48 = 12h)
    for _ in range(48):
        sim.step(commanded_battery_kw=0.0, heater_power_kw=0.0, active_tasks=[])

    baseline_solar = sim.true_state.solar_generated_kw
    assert baseline_solar > 15.0  # High solar during noon

    # Apply 50% solar fault
    fault = Fault(
        fault_id="pv_fault",
        category=FaultCategory.PHYSICAL_SOLAR,
        name="PV Loss",
        target="solar",
        start_step=48,
        duration_steps=10,
        severity=0.50,
        is_active=True,
    )

    sim.step(commanded_battery_kw=0.0, heater_power_kw=0.0, active_tasks=[], active_faults=[fault])
    faulted_solar = sim.true_state.solar_generated_kw
    assert faulted_solar == pytest.approx(baseline_solar * 0.50, rel=0.1)
