"""Unit tests for AstraGrid survival horizon estimator."""

import pytest
from astragrid.config import HabitatConfig
from astragrid.models import LimitingFactor, StateEstimate
from astragrid.safety.survival_horizon import SurvivalHorizonEstimator


def test_breached_boundary_returns_zero():
    """Verify estimator reports 0 hours immediately if boundary is already breached."""
    cfg = HabitatConfig()
    estimator = SurvivalHorizonEstimator(cfg)

    # Low SOC breach
    est_low_soc = StateEstimate(
        step=10,
        time_hours=2.5,
        estimated_soc=0.04,  # Below critical min 0.05
        soc_confidence=1.0,
        suspect_sensor_ids=[],
        estimated_battery_kwh=4.0,
        estimated_temp_c=21.0,
        estimated_solar_kw=0.0,
        estimated_load_kw=7.0,
    )
    res = estimator.estimate(est_low_soc, lambda t: 0.0)
    assert res.hours == 0.0
    assert res.limiting_factor == LimitingFactor.ENERGY_RESERVE

    # Low temperature breach
    est_low_temp = StateEstimate(
        step=10,
        time_hours=2.5,
        estimated_soc=0.85,
        soc_confidence=1.0,
        suspect_sensor_ids=[],
        estimated_battery_kwh=85.0,
        estimated_temp_c=14.0,  # Below critical min 15.0°C
        estimated_solar_kw=0.0,
        estimated_load_kw=7.0,
    )
    res_temp = estimator.estimate(est_low_temp, lambda t: 0.0)
    assert res_temp.hours == 0.0
    assert res_temp.limiting_factor == LimitingFactor.LOW_TEMPERATURE


def test_projected_survival_under_darkness():
    """Verify estimator projects finite hours to 20% reserve under zero solar generation."""
    cfg = HabitatConfig()
    estimator = SurvivalHorizonEstimator(cfg)

    # Initial state with 50% SOC (50 kWh). Safe reserve is 20% (20 kWh).
    # Usable surplus energy to safe reserve = 30 kWh.
    # Total essential load is ~7 kW. Expected survival ~ 30 / 7 ~ 4.2 hours.
    est = StateEstimate(
        step=0,
        time_hours=0.0,
        estimated_soc=0.50,
        soc_confidence=1.0,
        suspect_sensor_ids=[],
        estimated_battery_kwh=50.0,
        estimated_temp_c=21.0,
        estimated_solar_kw=0.0,
        estimated_load_kw=7.0,
    )

    # Zero solar forecast
    res = estimator.estimate(est, lambda t: 0.0, max_lookahead_steps=96)
    assert res.hours > 0.0
    assert res.hours < 10.0
    assert res.limiting_factor == LimitingFactor.ENERGY_RESERVE
