"""Integration tests running all standard AstraGrid scenarios."""

import pytest
from astragrid.models import OperatingMode, TaskStatus
from astragrid.orchestrator import AstraGridOrchestrator
from astragrid.scenarios.definitions import get_all_scenarios


@pytest.mark.parametrize(
    "scenario_id",
    [
        "nominal_day",
        "prolonged_solar_outage",
        "solar_array_damage",
        "battery_degradation",
        "byzantine_soc_sensor",
        "combined_fault",
        "hard_deadline_under_shortage",
    ],
)
def test_all_scenarios_run_to_completion(scenario_id: str):
    """Verify each bundled scenario runs full 24h horizon (96 steps) without error."""
    scenarios = get_all_scenarios()
    scenario = scenarios[scenario_id]

    orchestrator = AstraGridOrchestrator(scenario)
    for _ in range(scenario.config.simulation.total_steps):
        snap = orchestrator.step()

    assert len(orchestrator.history) == 96
    assert orchestrator.current_step == 96


def test_byzantine_scenario_isolates_sensor_2():
    """Verify byzantine_soc_sensor scenario detects and isolates sensor_2 during execution."""
    scenarios = get_all_scenarios()
    scenario = scenarios["byzantine_soc_sensor"]

    orchestrator = AstraGridOrchestrator(scenario)
    for _ in range(scenario.config.simulation.total_steps):
        orchestrator.step()

    assert "sensor_2" in orchestrator.estimator.isolated_sensors
    assert any(
        e.code == "SENSOR_OUTLIER_ISOLATED" and e.details.get("isolated_sensor") == "sensor_2"
        for e in orchestrator.all_events
    )


def test_combined_fault_enters_degraded_mode():
    """Verify combined_fault scenario transitions to DEGRADED mode."""
    scenarios = get_all_scenarios()
    scenario = scenarios["combined_fault"]

    orchestrator = AstraGridOrchestrator(scenario)
    for _ in range(scenario.config.simulation.total_steps):
        orchestrator.step()

    # Should have experienced DEGRADED mode
    assert any(snap.operating_mode == OperatingMode.DEGRADED for snap in orchestrator.history)


def test_hard_deadline_under_shortage_detects_infeasibility():
    """Verify hard_deadline_under_shortage flags task as INFEASIBLE_BY_DEADLINE."""
    scenarios = get_all_scenarios()
    scenario = scenarios["hard_deadline_under_shortage"]

    orchestrator = AstraGridOrchestrator(scenario)
    for _ in range(scenario.config.simulation.total_steps):
        orchestrator.step()

    # Emergency sample cooling should be flagged INFEASIBLE_BY_DEADLINE or MISSED_DEADLINE
    task = orchestrator.ledger.get_task("emergency_sample_cooling")
    assert task is not None
    assert task.status in (TaskStatus.INFEASIBLE_BY_DEADLINE, TaskStatus.MISSED_DEADLINE)
