# AstraGrid: Survival-Aware Energy Autonomy & Baseline Mission Scheduler for Lunar Habitats

**AstraGrid** is a simulation-driven, fault-aware energy-management and mission-scheduling controller for extreme lunar habitats. Its aim is not merely to minimize electricity usage. It keeps essential life-support services operating as safely as physical resources allow, detects when telemetry or hardware become unreliable, schedules flexible mission tasks around energy and thermal constraints, and transparently accounts for postponed work through a **Mission Debt Ledger**.

> **Product Definition:**
> AstraGrid estimates how long a simulated habitat can remain within critical energy and thermal limits, jointly schedules battery usage, equipment heat and flexible mission workloads, and replans as conditions change. When tasks must be postponed, it records them in a Mission Debt Ledger and plans their recovery when capacity returns. When hardware or telemetry becomes unreliable, it shifts into an appropriate degraded or emergency mode instead of blindly trusting corrupted inputs.

*Note: AstraGrid is a software simulation and decision-support prototype. It models discrete physical approximations and is not flight-qualified spacecraft software.*

---

## Architecture Overview

```text
astragrid/
├── config.py              # Validated Pydantic configuration schemas (Battery, Solar, Thermal, Sim)
├── models.py              # Domain models (OperatingMode, Task, TrueState, Telemetry, Events)
├── orchestrator.py        # Master closed-loop execution orchestrator
├── simulator/
│   └── engine.py          # Ground-truth physics simulator (battery dynamics, one-zone thermal, loads)
├── faults/
│   ├── models.py          # Fault definitions (Physical Solar/Battery, Byzantine Telemetry)
│   └── manager.py         # FaultManager with operating mode state machine and hysteresis
├── telemetry/
│   ├── sensors.py         # Multi-sensor telemetry generator with sensor noise and fault injection
│   └── estimator.py       # StateEstimator with 3-sensor median consensus and Coulomb-counting fallback
├── tasks/
│   └── debt_ledger.py     # Mission Debt Ledger with hard/soft deadline semantics & debt tracking
├── safety/
│   └── survival_horizon.py# Survival horizon forward-projection estimator (limiting factor analysis)
├── control/
│   ├── interface.py       # BaseController abstract class
│   ├── baseline.py        # Deterministic Baseline Priority Scheduler
│   └── plan_validator.py  # Independent PlanValidator verifying physical feasibility
├── scenarios/
│   └── definitions.py     # 7 standardized test and evaluation scenarios
└── dashboard/
    └── app.py             # Interactive Tkinter Mission Control Dashboard
cli.py                     # Command-line interface for traces, evaluation, and GUI launcher
tests/                     # Automated unit and integration test suite (26 tests)
```

---

## Core Subsystems

### 1. Discrete Physical Simulator
- **Energy Conservation**: Models solar generation curves, battery charge/discharge with asymmetric efficiencies ($\eta_{\text{ch}}=0.95, \eta_{\text{dis}}=0.95$), and prevents simultaneous charging and discharging.
- **One-Zone Thermal Dynamics**:
  $$\Delta T = \frac{\Delta t}{C_{\text{thermal}}} \cdot \left(\text{Heat}_{\text{in}} - \text{Heat}_{\text{loss}}\right)$$
  where $\text{Heat}_{\text{loss}} = UA \cdot (T - T_{\text{ext}})$ and $\text{Heat}_{\text{in}} = f_{\text{recoverable}} \cdot P_{\text{loads}} + \text{COP} \cdot P_{\text{heater}}$.

### 2. Telemetry Isolation & Estimator
- **State Estimation vs Ground Truth**: The estimator and controller **never** peek at hidden simulator state.
- **Byzantine Outlier Rejection**: Evaluates three independent SOC sensor channels. When an arbitrary/deceptive outlier occurs (e.g., Sensor 2 stuck at 75% while true SOC is 20%), median consensus isolates the faulty sensor and marks it suspect.
- **Physics Coulomb-Counting Fallback**: When multiple sensors conflict, the estimator falls back to energy-flow integration and flags low confidence.

### 3. Mission Debt Ledger
- Tracks task lifecycle states: `PENDING`, `SCHEDULED`, `DEFERRED`, `AT_RISK`, `INFEASIBLE_BY_DEADLINE`, `COMPLETED`, `MISSED_DEADLINE`.
- **Strict Deadline Semantics**: Hard deadlines are never silently extended or relaxed. Tasks that cannot physically finish in time are flagged as `INFEASIBLE_BY_DEADLINE`.
- **Debt Backlog**: Computes total deferred energy backlog in kWh and recovers workloads automatically when solar surplus returns.

### 4. Survival-Horizon Estimator
- Predicts how many hours/steps the habitat can survive under current battery reserve and thermal margins using a conservative life-support policy.
- Identifies primary limiting boundary: `energy_reserve`, `low_temperature`, `high_temperature`, or `none_within_horizon`.

### 5. Baseline Priority Scheduler
- Preserves life support unconditionally whenever physically feasible.
- Maintains habitat temperature within $[18^\circ\text{C}, 24^\circ\text{C}]$ using dynamic heater regulation.
- Allocates available solar power:
  1. Active mandatory loads (ECLSS + heater)
  2. Permitted flexible workloads (sorted by Hard deadline, urgency ratio, priority, mission value)
  3. Battery recharge (prioritized first if battery is below 20% safe reserve)
- Protects battery reserve by shedding or deferring flexible tasks during solar deficit.

---

## Interactive Tkinter Dashboard

The desktop GUI is structured into three clean, dedicated pages with persistent audit logging and dynamic task injection:

1. **🛰️ Telemetry & Power Overview**:
   - **Real-Time Telemetry Cards**: State of charge, battery flow (kW), solar output, load, internal temperature, heater power, and survival horizon.
   - **Multi-Sensor Health**: Live readouts of Sensors 1, 2, and 3, outlier detection badges, and confidence metrics.
   - **Large Visual Canvas History Graphs**: Spacious, full-height curves for SOC % (with 20% safe reserve line), Power Flows (Solar vs Load), and Thermal Comfort Zone ($[18^\circ\text{C}, 24^\circ\text{C}]$).
   - **On-the-Fly Fault Injection**: Interactive buttons to trigger 50% solar loss, Byzantine SOC sensor corruption, or battery degradation in real time.

2. **📋 Mission Debt Ledger & Workloads**:
   - **Full-Width Workloads Table**: Tabular view of Task ID, Name, Power (kW), Duration (h), Expected Energy (kWh), Deadline (h), Deadline Type, Priority, Status, Progress %, and Deferral counts.
   - **➕ Dynamic Task Addition Form**: Allows adding custom mission tasks at runtime with automatically calculated expected energy ($P \times \text{Duration} = E \text{ kWh}$), strict hard/soft deadlines, and priority levels.

3. **📜 Audit Trail & Logs**:
   - **Disk-Based Logging**: Automatically persists all structured events and decisions to `logs/astragrid_audit_trail.log`.
   - **Dedicated Log Viewer**: Full-screen scrollable event feed with colored severity tags, category filters (`ALL`, `WARNING`, `EMERGENCY`, `CRITICAL`, `LEDGER`), and an **"Open Log File"** button to view in external text editors.

---

## Standard Scenarios

| Scenario ID | Name | Description |
|---|---|---|
| `nominal_day` | Nominal Day Operation | Standard diurnal solar cycle, healthy battery, standard tasks. |
| `prolonged_solar_outage` | Prolonged Solar Outage | 90% solar reduction (dust storm/eclipse) from step 24 to 56. |
| `solar_array_damage` | Solar Array Damage | Persistent 50% loss in solar array output starting at step 16. |
| `battery_degradation` | Battery Degradation | Usable battery capacity and discharge rate reduced by 50% at step 20. |
| `byzantine_soc_sensor` | Byzantine SOC Outlier | Sensor 2 deceptively reports 75% SOC at step 16 while true SOC drops; estimator isolates it. |
| `combined_fault` | Combined Solar & Sensor Fault | 50% solar panel loss combined with deceptive Sensor 2 reporting 80% SOC. |
| `hard_deadline_under_shortage` | Hard Deadline Under Shortage | Heavy task with tight hard deadline during deficit; verifies deadline infeasibility detection. |

---

## Quickstart & Commands

### Prerequisites
Python 3.11+ with `pydantic`, `numpy`, and `pytest`.

```bash
# Clone or navigate to the repository
cd sedsHackdemo
```

### Launch the Tkinter Dashboard
```bash
python cli.py --gui
# or
python -m astragrid.dashboard.app
```

### Run Scenarios in Headless CLI Mode
```bash
# Run nominal day scenario for 40 steps (10 hours)
python cli.py --scenario nominal_day --steps 40

# Run Byzantine sensor scenario
python cli.py --scenario byzantine_soc_sensor --steps 30

# Run combined fault scenario
python cli.py --scenario combined_fault --steps 30
```

### Run Multi-Scenario Benchmark Suite
```bash
python cli.py --eval
```

### Run Automated Tests
```bash
python -m pytest tests
```
