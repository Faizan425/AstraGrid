"""Command Line Interface (CLI) for AstraGrid.

Allows running scenarios in headless mode with tabular step traces,
evaluating all scenarios, or launching the Tkinter dashboard.
"""

from __future__ import annotations
import argparse
import sys
from astragrid.orchestrator import AstraGridOrchestrator
from astragrid.scenarios.definitions import get_all_scenarios


def run_scenario_cli(scenario_id: str, steps: int = 96, verbose: bool = True):
    """Run a scenario in headless CLI mode and print formatted execution trace."""
    scenarios = get_all_scenarios()
    if scenario_id not in scenarios:
        print(f"Error: Unknown scenario '{scenario_id}'. Available: {list(scenarios.keys())}")
        sys.exit(1)

    scenario = scenarios[scenario_id]
    print("=" * 88)
    print(f"  ASTRAGRID: Running Scenario '{scenario.name}' ({scenario_id})")
    print(f"  Description: {scenario.description}")
    print("=" * 88)

    orchestrator = AstraGridOrchestrator(scenario)

    header = f"{'Step':>4} | {'Time':>6} | {'Mode':<10} | {'Est SOC':>7} | {'Solar(kW)':>9} | {'Load(kW)':>8} | {'Temp(C)':>7} | {'Surv(h)':>7} | {'Debt(kWh)':>9} | {'Action / Reason'}"
    print(header)
    print("-" * 115)

    for i in range(min(steps, scenario.config.simulation.total_steps)):
        snap = orchestrator.step()
        sched_str = ",".join(snap.scheduled_tasks) if snap.scheduled_tasks else "None"
        deff_str = f" [Def: {','.join(snap.deferred_tasks)}]" if snap.deferred_tasks else ""
        action_summary = f"{sched_str}{deff_str} | {snap.action_reason}"

        print(
            f"{snap.step:4d} | "
            f"{snap.time_hours:5.2f}h | "
            f"{snap.operating_mode.value:<10} | "
            f"{snap.estimated_soc*100:6.1f}% | "
            f"{snap.solar_gen_kw:9.2f} | "
            f"{snap.total_load_kw:8.2f} | "
            f"{snap.habitat_temp_c:6.1f}C | "
            f"{snap.survival_hours:6.1f}h | "
            f"{snap.mission_debt_kwh:8.1f}k | "
            f"{action_summary[:40]}"
        )

    print("-" * 115)
    print("\nFINAL MISSION SUMMARY:")
    print(f"  - Completed Tasks: {orchestrator.ledger.completed_task_count}")
    print(f"  - Deferred Tasks: {orchestrator.ledger.deferred_task_count}")
    print(f"  - Outstanding Mission Debt Backlog: {orchestrator.ledger.total_mission_debt_kwh:.2f} kWh")
    print(f"  - Final Operating Mode: {orchestrator.fault_manager.current_mode.value}")
    print(f"  - Total Recorded Events: {len(orchestrator.all_events)}")
    print("=" * 88)


def evaluate_all_scenarios():
    """Run all 7 scenarios and display comparative summary."""
    scenarios = get_all_scenarios()
    print("=" * 95)
    print(f"  ASTRAGRID: Multi-Scenario Benchmark Suite ({len(scenarios)} Scenarios)")
    print("=" * 95)
    print(f"{'Scenario ID':<28} | {'Mode':<10} | {'End SOC':>7} | {'Completed':>9} | {'Debt Backlog':>12} | {'Events':>6}")
    print("-" * 95)

    for s_id, scenario in scenarios.items():
        orch = AstraGridOrchestrator(scenario)
        for _ in range(scenario.config.simulation.total_steps):
            orch.step()

        last_snap = orch.history[-1]
        print(
            f"{s_id:<28} | "
            f"{last_snap.operating_mode.value:<10} | "
            f"{last_snap.estimated_soc*100:6.1f}% | "
            f"{orch.ledger.completed_task_count:9d} | "
            f"{orch.ledger.total_mission_debt_kwh:10.1f} kWh | "
            f"{len(orch.all_events):6d}"
        )
    print("=" * 95)


def main():
    parser = argparse.ArgumentParser(description="AstraGrid Lunar Habitat Baseline Scheduler & Simulator CLI")
    parser.add_argument("--gui", action="store_true", help="Launch the interactive Tkinter mission control dashboard")
    parser.add_argument("--scenario", type=str, default="nominal_day", help="Scenario ID to run (e.g., nominal_day, byzantine_soc_sensor, combined_fault)")
    parser.add_argument("--steps", type=int, default=96, help="Number of timesteps to run (default: 96 = 24h)")
    parser.add_argument("--eval", action="store_true", help="Run comparative benchmark across all 7 scenarios")

    args = parser.parse_args()

    if args.gui or len(sys.argv) == 1:
        # Launch GUI by default if no arguments provided
        try:
            from astragrid.dashboard.app import main as launch_gui
            launch_gui()
        except Exception as e:
            print(f"Failed to launch GUI: {e}. Falling back to CLI trace.")
            run_scenario_cli(args.scenario, args.steps)
    elif args.eval:
        evaluate_all_scenarios()
    else:
        run_scenario_cli(args.scenario, args.steps)


if __name__ == "__main__":
    main()
