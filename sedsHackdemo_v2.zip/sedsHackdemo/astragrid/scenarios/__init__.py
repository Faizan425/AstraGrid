"""AstraGrid scenario management."""

from astragrid.scenarios.definitions import Scenario, get_all_scenarios

__all__ = ["Scenario", "get_all_scenarios"]
