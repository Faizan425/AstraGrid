"""Pre-configured scenario definitions for AstraGrid."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List
from astragrid.config import HabitatConfig
from astragrid.faults.models import Fault
from astragrid.models import DeadlineType, FaultCategory, Task


@dataclass
class Scenario:
    """A complete scenario bundle."""
    scenario_id: str
    name: str
    description: str
    config: HabitatConfig
    tasks: List[Task]
    faults: List[Fault] = field(default_factory=list)


def get_default_tasks() -> List[Task]:
    """Standard baseline mission task queue."""
    return [
        Task(
            id="regolith_analysis",
            name="Regolith Core Spectrometry",
            power_kw=3.5,
            duration_hours=3.0,
            release_hour=2.0,
            deadline_hour=14.0,
            deadline_type=DeadlineType.SOFT,
            priority=2,
            mission_value=120.0,
        ),
        Task(
            id="rover_recharge",
            name="Survey Rover Rapid Recharge",
            power_kw=5.0,
            duration_hours=2.5,
            release_hour=4.0,
            deadline_hour=12.0,
            deadline_type=DeadlineType.HARD,
            priority=1,
            mission_value=200.0,
        ),
        Task(
            id="greenhouse_lighting",
            name="Hydroponic Growth Supplementary Light",
            power_kw=2.0,
            duration_hours=6.0,
            release_hour=6.0,
            deadline_hour=20.0,
            deadline_type=DeadlineType.SOFT,
            priority=3,
            mission_value=80.0,
        ),
        Task(
            id="deep_space_tx",
            name="Earth Deep Space Science Downlink",
            power_kw=4.0,
            duration_hours=2.0,
            release_hour=10.0,
            deadline_hour=18.0,
            deadline_type=DeadlineType.HARD,
            priority=1,
            mission_value=250.0,
        ),
    ]


def get_all_scenarios() -> dict[str, Scenario]:
    """Build and return dictionary of all 7 standard evaluation scenarios."""
    scenarios: dict[str, Scenario] = {}

    # 1. Nominal Day
    scenarios["nominal_day"] = Scenario(
        scenario_id="nominal_day",
        name="Nominal Day Operation",
        description="Normal cyclic solar generation, viable battery, and standard task queue.",
        config=HabitatConfig(),
        tasks=get_default_tasks(),
        faults=[],
    )

    # 2. Prolonged Solar Outage
    scenarios["prolonged_solar_outage"] = Scenario(
        scenario_id="prolonged_solar_outage",
        name="Prolonged Solar Outage",
        description="Severe solar outage (90% reduction) simulating eclipse or lunar dust storm from step 24 to 56 (6h to 14h).",
        config=HabitatConfig(),
        tasks=get_default_tasks(),
        faults=[
            Fault(
                fault_id="outage_dust_storm",
                category=FaultCategory.PHYSICAL_SOLAR,
                name="Solar Dust Occlusion Outage",
                target="solar",
                start_step=24,
                duration_steps=32,  # 8 hours
                severity=0.10,  # Only 10% solar remains
            )
        ],
    )

    # 3. Solar Array Damage
    scenarios["solar_array_damage"] = Scenario(
        scenario_id="solar_array_damage",
        name="Solar Array Hardware Damage",
        description="Persistent 50% drop in available solar-array generation due to micrometeoroid damage starting at step 16 (4h).",
        config=HabitatConfig(),
        tasks=get_default_tasks(),
        faults=[
            Fault(
                fault_id="pv_damage_micrometeoroid",
                category=FaultCategory.PHYSICAL_SOLAR,
                name="Solar Panel Array Damage",
                target="solar",
                start_step=16,
                duration_steps=-1,  # Persistent
                severity=0.50,  # 50% loss
            )
        ],
    )

    # 4. Battery Degradation
    scenarios["battery_degradation"] = Scenario(
        scenario_id="battery_degradation",
        name="Battery Capacity Degradation",
        description="Battery suffers internal cell fault at step 20; usable capacity reduced by 50% and max discharge rate restricted.",
        config=HabitatConfig(),
        tasks=get_default_tasks(),
        faults=[
            Fault(
                fault_id="batt_cell_failure",
                category=FaultCategory.PHYSICAL_BATTERY,
                name="Battery Cell Pack Degradation",
                target="battery_capacity",
                start_step=20,
                duration_steps=-1,
                severity=0.50,
            ),
            Fault(
                fault_id="batt_discharge_restriction",
                category=FaultCategory.PHYSICAL_BATTERY,
                name="Discharge Inverter Thermal Throttling",
                target="battery_discharge",
                start_step=20,
                duration_steps=-1,
                severity=0.50,
            ),
        ],
    )

    # 5. Byzantine SOC Sensor
    scenarios["byzantine_soc_sensor"] = Scenario(
        scenario_id="byzantine_soc_sensor",
        name="Byzantine SOC Telemetry Outlier",
        description="Sensor 2 falsely and misleadingly reports high 75% SOC at step 16 while true SOC is actively depleting.",
        config=HabitatConfig(),
        tasks=get_default_tasks(),
        faults=[
            Fault(
                fault_id="byzantine_sensor_2",
                category=FaultCategory.TELEMETRY_SOC_OUTLIER,
                name="Sensor 2 Byzantine Deceptive Telemetry",
                target="sensor_2",
                start_step=16,
                duration_steps=-1,
                severity=0.75,
                params={"outlier_value": 0.75},
            )
        ],
    )

    # 6. Combined Fault
    scenarios["combined_fault"] = Scenario(
        scenario_id="combined_fault",
        name="Combined Solar Damage & Byzantine Sensor",
        description="Interacting faults: persistent 50% solar panel loss plus deceitful Sensor 2 reporting 80% SOC.",
        config=HabitatConfig(),
        tasks=get_default_tasks(),
        faults=[
            Fault(
                fault_id="pv_damage_micrometeoroid",
                category=FaultCategory.PHYSICAL_SOLAR,
                name="Solar Panel Array Damage",
                target="solar",
                start_step=12,
                duration_steps=-1,
                severity=0.50,
            ),
            Fault(
                fault_id="byzantine_sensor_2",
                category=FaultCategory.TELEMETRY_SOC_OUTLIER,
                name="Sensor 2 Byzantine Telemetry",
                target="sensor_2",
                start_step=16,
                duration_steps=-1,
                severity=0.80,
                params={"outlier_value": 0.80},
            ),
        ],
    )

    # 7. Hard Deadline Under Shortage
    hard_tasks = [
        Task(
            id="emergency_sample_cooling",
            name="Cryogenic Lunar Ice Sample Stabilization",
            power_kw=7.0,
            duration_hours=4.0,
            release_hour=2.0,
            deadline_hour=6.5,  # Very tight hard deadline!
            deadline_type=DeadlineType.HARD,
            priority=1,
            mission_value=300.0,
        ),
        Task(
            id="routine_habitat_cleanse",
            name="CO2 Scrubber Deep Cycle",
            power_kw=3.0,
            duration_hours=3.0,
            release_hour=1.0,
            deadline_hour=10.0,
            deadline_type=DeadlineType.SOFT,
            priority=3,
            mission_value=50.0,
        ),
    ]
    scenarios["hard_deadline_under_shortage"] = Scenario(
        scenario_id="hard_deadline_under_shortage",
        name="Hard Deadline Under Resource Shortage",
        description="Heavy task with strict hard deadline during severe generation deficit; demonstrates deadline infeasibility detection without relaxing limits.",
        config=HabitatConfig(),
        tasks=hard_tasks,
        faults=[
            Fault(
                fault_id="cloud_outage",
                category=FaultCategory.PHYSICAL_SOLAR,
                name="Solar Dust Shielding",
                target="solar",
                start_step=8,
                duration_steps=20,
                severity=0.20,
            )
        ],
    )

    return scenarios
