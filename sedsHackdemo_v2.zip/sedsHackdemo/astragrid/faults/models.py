"""Fault management and disturbance injection models for AstraGrid."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict
from astragrid.models import FaultCategory


@dataclass
class Fault:
    """A physical or telemetry fault specification."""
    fault_id: str
    category: FaultCategory
    name: str
    target: str  # e.g., "solar", "battery", "sensor_2", "environment"
    start_step: int
    duration_steps: int = -1  # -1 means persistent until end
    severity: float = 1.0  # e.g., 0.5 for 50% solar loss, or specific value
    params: Dict[str, Any] = field(default_factory=dict)
    
    # Live status
    is_active: bool = False
    is_detected: bool = False
    is_isolated: bool = False

    def is_step_active(self, step: int) -> bool:
        """Check if fault should be active at the given simulation step."""
        if step < self.start_step:
            return False
        if self.duration_steps == -1:
            return True
        return step < (self.start_step + self.duration_steps)
