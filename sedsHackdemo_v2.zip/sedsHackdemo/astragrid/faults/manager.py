"""Central operational coordinator and operating mode manager."""

from __future__ import annotations
from typing import List, Optional
from astragrid.config import HabitatConfig
from astragrid.faults.models import Fault
from astragrid.models import OperatingMode, StateEstimate, StructuredEvent


class FaultManager:
    """Coordinates active faults and maintains operating mode state machine with hysteresis."""

    def __init__(self, config: HabitatConfig, faults: Optional[List[Fault]] = None):
        self.config = config
        self.faults: List[Fault] = faults or []
        self.current_mode: OperatingMode = OperatingMode.NORMAL
        self.mode_reason: str = "Nominal operation"
        self._consecutive_healthy_steps: int = 0
        self._required_healthy_steps_for_recovery: int = 2

    def update_faults(self, step: int) -> List[StructuredEvent]:
        """Update active states of all faults for the current step."""
        events: List[StructuredEvent] = []
        time_hours = step * self.config.simulation.dt_hours

        for fault in self.faults:
            was_active = fault.is_active
            is_active_now = fault.is_step_active(step)
            fault.is_active = is_active_now

            if not was_active and is_active_now:
                events.append(
                    StructuredEvent(
                        step=step,
                        time_hours=time_hours,
                        category="FAULT",
                        severity="WARNING",
                        source="FaultInjector",
                        code="FAULT_ACTIVATED",
                        message=f"Fault '{fault.name}' ({fault.fault_id}) activated on target '{fault.target}'",
                        details={"category": fault.category.value, "severity": fault.severity},
                    )
                )
            elif was_active and not is_active_now:
                events.append(
                    StructuredEvent(
                        step=step,
                        time_hours=time_hours,
                        category="FAULT",
                        severity="INFO",
                        source="FaultInjector",
                        code="FAULT_CLEARED",
                        message=f"Fault '{fault.name}' ({fault.fault_id}) ended",
                        details={"category": fault.category.value},
                    )
                )
        return events

    def evaluate_operating_mode(
        self,
        step: int,
        estimate: StateEstimate,
        unmet_essential_load_kw: float = 0.0,
    ) -> tuple[OperatingMode, Optional[StructuredEvent]]:
        """Evaluate mode transitions based on state estimates, telemetry quality, and active hardware faults."""
        time_hours = step * self.config.simulation.dt_hours
        new_mode = OperatingMode.NORMAL
        reason = "System nominal"
        severity = "INFO"

        soc = estimate.estimated_soc
        temp = estimate.estimated_temp_c
        conf = estimate.soc_confidence
        critical_soc = self.config.battery.critical_min_soc
        min_reserve = self.config.battery.min_reserve_soc
        crit_min_temp = self.config.thermal.critical_min_temp_c
        crit_max_temp = self.config.thermal.critical_max_temp_c
        min_temp = self.config.thermal.min_safe_temp_c
        max_temp = self.config.thermal.max_safe_temp_c

        # 1. Check for Emergency or Shutdown (meaningful deficit, > 1.0 kW)
        if unmet_essential_load_kw > 1.0:
            new_mode = OperatingMode.CONTROLLED_SHUTDOWN
            reason = f"Essential life-support load unmet ({unmet_essential_load_kw:.2f} kW). Orderly shutdown initiated."
            severity = "CRITICAL"
        elif soc <= critical_soc:
            new_mode = OperatingMode.EMERGENCY
            reason = f"Estimated battery SOC ({soc*100:.1f}%) breached critical threshold ({critical_soc*100:.1f}%)"
            severity = "EMERGENCY"
        elif temp <= crit_min_temp or temp >= crit_max_temp:
            new_mode = OperatingMode.EMERGENCY
            reason = f"Habitat temperature ({temp:.1f}°C) breached critical bounds [{crit_min_temp}, {crit_max_temp}]"
            severity = "EMERGENCY"
        # 2. Check for Degraded Mode
        elif (
            soc < min_reserve
            or temp < min_temp
            or temp > max_temp
            or conf < 0.80
            or len(estimate.suspect_sensor_ids) > 0
            or any(f.is_active for f in self.faults)
        ):
            new_mode = OperatingMode.DEGRADED
            reasons = []
            if soc < min_reserve:
                reasons.append(f"SOC ({soc*100:.1f}%) below safe reserve ({min_reserve*100:.1f}%)")
            if temp < min_temp or temp > max_temp:
                reasons.append(f"Temp ({temp:.1f}°C) outside safe band [{min_temp}, {max_temp}]")
            if conf < 0.80:
                reasons.append(f"Low telemetry confidence ({conf*100:.0f}%)")
            if estimate.suspect_sensor_ids:
                reasons.append(f"Suspect sensors: {', '.join(estimate.suspect_sensor_ids)}")
            active_fault_names = [f.name for f in self.faults if f.is_active]
            if active_fault_names:
                reasons.append(f"Active faults: {', '.join(active_fault_names)}")
            reason = "; ".join(reasons)
            severity = "WARNING"
        else:
            new_mode = OperatingMode.NORMAL
            reason = "Telemetry consistent and physical margins nominal"

        # Apply hysteresis for returning to NORMAL from DEGRADED
        event: Optional[StructuredEvent] = None
        if self.current_mode in (OperatingMode.DEGRADED, OperatingMode.EMERGENCY) and new_mode == OperatingMode.NORMAL:
            self._consecutive_healthy_steps += 1
            if self._consecutive_healthy_steps < self._required_healthy_steps_for_recovery:
                # Retain DEGRADED until hysteresis condition met
                return self.current_mode, None
            else:
                self._consecutive_healthy_steps = 0
        elif new_mode != OperatingMode.NORMAL:
            self._consecutive_healthy_steps = 0

        if new_mode != self.current_mode:
            old_mode = self.current_mode
            self.current_mode = new_mode
            self.mode_reason = reason
            event = StructuredEvent(
                step=step,
                time_hours=time_hours,
                category="SAFETY",
                severity=severity,
                source="FaultManager",
                code="MODE_TRANSITION",
                message=f"Operating mode shifted from {old_mode.value} to {new_mode.value}: {reason}",
                details={"old_mode": old_mode.value, "new_mode": new_mode.value, "reason": reason},
            )

        return self.current_mode, event
