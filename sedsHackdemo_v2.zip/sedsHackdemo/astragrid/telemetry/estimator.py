"""State Estimator and Telemetry Validator for AstraGrid.

Performs robust multi-sensor consensus and physics-based sanity checks
without ever reading simulator ground truth.
"""

from __future__ import annotations
import statistics
from typing import List, Optional, Tuple
from astragrid.config import HabitatConfig
from astragrid.models import StateEstimate, StructuredEvent, TelemetryObservation


class StateEstimator:
    """Robust state estimator that operates exclusively on reported telemetry and energy conservation."""

    def __init__(self, config: HabitatConfig, outlier_threshold: float = 0.12):
        self.config = config
        self.outlier_threshold = outlier_threshold
        self.isolated_sensors: set[str] = set()

    def estimate_state(
        self,
        observation: TelemetryObservation,
        prior_estimate: Optional[StateEstimate],
        commanded_battery_kw: float = 0.0,
    ) -> Tuple[StateEstimate, List[StructuredEvent]]:
        """Compute estimated state using median consensus, residual checks, and energy integration fallback."""
        events: List[StructuredEvent] = []
        step = observation.step
        time_hours = observation.time_hours
        capacity = self.config.battery.usable_capacity_kwh
        dt = self.config.simulation.dt_hours

        # 1. Project expected SOC based on prior estimate and commanded battery power (Coulomb-counting check)
        expected_soc_from_physics: Optional[float] = None
        if prior_estimate is not None:
            if commanded_battery_kw >= 0:
                delta_kwh = commanded_battery_kw * self.config.battery.charge_efficiency * dt
            else:
                delta_kwh = (commanded_battery_kw / self.config.battery.discharge_efficiency) * dt
            expected_soc_from_physics = max(0.0, min(1.0, prior_estimate.estimated_soc + (delta_kwh / capacity)))

        # 2. Inspect available SOC sensor channels
        raw_readings = observation.soc_readings
        active_readings = {s_id: val for s_id, val in raw_readings.items() if s_id not in self.isolated_sensors}

        suspect_sensors: List[str] = list(self.isolated_sensors)
        consensus_soc = 0.85
        confidence = 1.0
        method = "MULTI_SENSOR_CONSENSUS"

        if len(active_readings) >= 3:
            values = list(active_readings.values())
            med_val = statistics.median(values)

            # Check individual residuals against median
            outliers = [s_id for s_id, val in active_readings.items() if abs(val - med_val) > self.outlier_threshold]

            if len(outliers) == 1:
                outlier_id = outliers[0]
                self.isolated_sensors.add(outlier_id)
                suspect_sensors.append(outlier_id)
                
                # Consensus among remaining trusted sensors
                trusted_values = [val for s_id, val in active_readings.items() if s_id != outlier_id]
                consensus_soc = statistics.mean(trusted_values)
                confidence = 0.85
                method = "MEDIAN_OUTLIER_REJECTION"

                events.append(
                    StructuredEvent(
                        step=step,
                        time_hours=time_hours,
                        category="TELEMETRY",
                        severity="WARNING",
                        source="StateEstimator",
                        code="SENSOR_OUTLIER_ISOLATED",
                        message=(
                            f"Sensor '{outlier_id}' reported {raw_readings[outlier_id]*100:.1f}%, deviating "
                            f"> {self.outlier_threshold*100:.0f}% from consensus ({med_val*100:.1f}%). Isolated."
                        ),
                        details={
                            "isolated_sensor": outlier_id,
                            "reported_value": raw_readings[outlier_id],
                            "median_consensus": med_val,
                        },
                    )
                )
            elif len(outliers) > 1:
                # Widespread disagreement! Fallback to physics integration if available
                confidence = 0.40
                if expected_soc_from_physics is not None:
                    consensus_soc = expected_soc_from_physics
                    method = "PHYSICS_INTEGRATION_FALLBACK"
                else:
                    consensus_soc = med_val
                    method = "UNCERTAIN_MEDIAN"
                
                events.append(
                    StructuredEvent(
                        step=step,
                        time_hours=time_hours,
                        category="TELEMETRY",
                        severity="EMERGENCY",
                        source="StateEstimator",
                        code="SENSOR_CONSENSUS_FAILURE",
                        message="Multiple SOC sensors disagree. Reduced confidence and triggered conservative fallback.",
                        details={"readings": raw_readings},
                    )
                )
            else:
                # All active sensors agree
                consensus_soc = statistics.mean(values)
                confidence = 1.0

        elif len(active_readings) in (1, 2):
            # Reduced redundancy: compare against expected energy flow
            if expected_soc_from_physics is not None:
                # Weight towards energy balance
                s_mean = statistics.mean(active_readings.values())
                if abs(s_mean - expected_soc_from_physics) > self.outlier_threshold:
                    consensus_soc = expected_soc_from_physics
                    confidence = 0.60
                    method = "ENERGY_BALANCE_WEIGHTED"
                else:
                    consensus_soc = 0.5 * s_mean + 0.5 * expected_soc_from_physics
                    confidence = 0.75
            else:
                consensus_soc = statistics.mean(active_readings.values())
                confidence = 0.70
        else:
            # All sensors isolated
            confidence = 0.25
            consensus_soc = expected_soc_from_physics if expected_soc_from_physics is not None else 0.50
            method = "BLIND_DEAD_RECKONING"

        # Sanity bound [0.0, 1.0]
        consensus_soc = max(0.0, min(1.0, consensus_soc))
        estimated_battery_kwh = consensus_soc * capacity

        estimate = StateEstimate(
            step=step,
            time_hours=time_hours,
            estimated_soc=round(consensus_soc, 4),
            soc_confidence=round(confidence, 2),
            suspect_sensor_ids=list(set(suspect_sensors)),
            estimated_battery_kwh=round(estimated_battery_kwh, 2),
            estimated_temp_c=observation.temp_c,
            estimated_solar_kw=observation.solar_kw,
            estimated_load_kw=observation.total_load_kw,
            estimation_method=method,
        )
        return estimate, events
