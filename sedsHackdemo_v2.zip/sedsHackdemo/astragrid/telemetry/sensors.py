"""Telemetry generation and observation models."""

from __future__ import annotations
import random
from typing import List, Optional
from astragrid.config import HabitatConfig
from astragrid.faults.models import Fault
from astragrid.models import FaultCategory, TelemetryObservation, TruePhysicalState


class TelemetryGenerator:
    """Generates sensor observations from physical state, applying sensor noise and telemetry faults.
    
    This acts as the hardware sensor suite.
    """

    def __init__(self, config: HabitatConfig):
        self.config = config
        self._rng = random.Random(config.simulation.random_seed)

    def generate_observation(
        self,
        true_state: TruePhysicalState,
        active_faults: Optional[List[Fault]] = None,
    ) -> TelemetryObservation:
        """Create sensor readings. Telemetry faults corrupt readings here without altering true physics."""
        active_faults = active_faults or []
        noise_soc_1 = self._rng.gauss(0.0, 0.003)
        noise_soc_2 = self._rng.gauss(0.0, 0.003)
        noise_soc_3 = self._rng.gauss(0.0, 0.003)

        soc_readings = {
            "sensor_1": max(0.0, min(1.0, true_state.true_soc + noise_soc_1)),
            "sensor_2": max(0.0, min(1.0, true_state.true_soc + noise_soc_2)),
            "sensor_3": max(0.0, min(1.0, true_state.true_soc + noise_soc_3)),
        }

        # Apply any active telemetry faults
        for fault in active_faults:
            if not fault.is_active:
                continue
            if fault.category == FaultCategory.TELEMETRY_SOC_OUTLIER and fault.target in soc_readings:
                # Byzantine / misleading sensor value (e.g. pinned to 0.75 or arbitrary high value)
                forced_val = fault.params.get("outlier_value", fault.severity)
                soc_readings[fault.target] = forced_val
            elif fault.category == FaultCategory.TELEMETRY_BIAS and fault.target in soc_readings:
                bias = fault.params.get("bias", 0.20)
                soc_readings[fault.target] = max(0.0, min(1.0, soc_readings[fault.target] + bias))

        temp_noise = self._rng.gauss(0.0, 0.05)
        temp_reading = true_state.habitat_temp_c + temp_noise

        solar_reading = max(0.0, true_state.solar_generated_kw + self._rng.gauss(0.0, 0.05))
        total_load = true_state.essential_load_kw + true_state.active_task_load_kw + true_state.heater_power_kw

        return TelemetryObservation(
            step=true_state.step,
            time_hours=true_state.time_hours,
            soc_readings=soc_readings,
            temp_c=round(temp_reading, 2),
            solar_kw=round(solar_reading, 2),
            total_load_kw=round(total_load, 2),
            battery_net_power_kw=round(true_state.battery_power_kw, 2),
        )
