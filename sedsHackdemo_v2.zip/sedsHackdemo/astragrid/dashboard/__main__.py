"""Entry point for python -m astragrid.dashboard."""

from astragrid.dashboard.app import main

if __name__ == "__main__":
    main()
