"""Survival Horizon Estimator for AstraGrid.

Forecasts habitat survivability margin under conservative emergency policy.
"""

from __future__ import annotations
import math
from typing import Callable, Optional
from astragrid.config import HabitatConfig
from astragrid.models import LimitingFactor, StateEstimate, SurvivalHorizon


class SurvivalHorizonEstimator:
    """Estimates how long the habitat can remain within critical boundaries under conservative policy."""

    def __init__(self, config: HabitatConfig):
        self.config = config

    def estimate(
        self,
        estimate: StateEstimate,
        solar_forecast_fn: Callable[[float], float],
        max_lookahead_steps: int = 96,  # 24 hours
    ) -> SurvivalHorizon:
        """Project forward step-by-step from current estimated state under conservative survival policy."""
        dt = self.config.simulation.dt_hours
        capacity = self.config.battery.usable_capacity_kwh
        eff_dis = self.config.battery.discharge_efficiency
        eff_ch = self.config.battery.charge_efficiency
        min_reserve_soc = self.config.battery.min_reserve_soc
        crit_min_soc = self.config.battery.critical_min_soc
        crit_min_temp = self.config.thermal.critical_min_temp_c
        crit_max_temp = self.config.thermal.critical_max_temp_c
        min_safe_temp = self.config.thermal.min_safe_temp_c
        ua = self.config.thermal.envelope_ua_kw_per_c
        ext_temp = self.config.thermal.default_ext_temp_c
        cap_c = self.config.thermal.thermal_capacity_kwh_per_c

        # 1. Check if boundary already breached
        if estimate.estimated_soc <= crit_min_soc:
            return SurvivalHorizon(
                hours=0.0,
                steps=0,
                limiting_factor=LimitingFactor.ENERGY_RESERVE,
                assumptions="Battery SOC currently at or below critical minimum limit.",
            )
        if estimate.estimated_temp_c <= crit_min_temp:
            return SurvivalHorizon(
                hours=0.0,
                steps=0,
                limiting_factor=LimitingFactor.LOW_TEMPERATURE,
                assumptions="Habitat temperature currently at or below critical lower thermal limit.",
            )
        if estimate.estimated_temp_c >= crit_max_temp:
            return SurvivalHorizon(
                hours=0.0,
                steps=0,
                limiting_factor=LimitingFactor.HIGH_TEMPERATURE,
                assumptions="Habitat temperature currently at or above critical upper thermal limit.",
            )

        # 2. Forward projection simulation
        sim_energy = estimate.estimated_soc * capacity
        sim_temp = estimate.estimated_temp_c
        essential_load_kw = sum(e.power_kw for e in self.config.essential_loads)

        for step_ahead in range(1, max_lookahead_steps + 1):
            t_ahead = estimate.time_hours + (step_ahead * dt)
            expected_solar = solar_forecast_fn(t_ahead)

            # Conservative thermal policy: heat loss = UA * (T - T_ext)
            heat_loss = ua * (sim_temp - ext_temp)
            # Recoverable heat from essential loads
            recov_heat = self.config.thermal.recoverable_heat_fraction * essential_load_kw
            
            # Needed heater power to keep at least min_safe_temp
            heater_needed_kw = 0.0
            if sim_temp < min_safe_temp:
                # Target temp rise
                delta_t_needed = (min_safe_temp - sim_temp)
                heat_needed = (delta_t_needed * cap_c / dt) + heat_loss - recov_heat
                heater_needed_kw = max(0.0, min(self.config.thermal.heater_max_power_kw, heat_needed / self.config.thermal.heater_cop))

            # Total conservative load
            total_cons_demand = essential_load_kw + heater_needed_kw
            net_power = expected_solar - total_cons_demand

            if net_power >= 0:
                # Surplus: charge battery
                charge_power = min(net_power, self.config.battery.max_charge_kw)
                sim_energy = min(capacity, sim_energy + charge_power * eff_ch * dt)
            else:
                # Deficit: discharge battery
                discharge_power = min(abs(net_power), self.config.battery.max_discharge_kw)
                sim_energy = max(0.0, sim_energy - (discharge_power / eff_dis) * dt)

            # Update temperature
            heat_in = recov_heat + (heater_needed_kw * self.config.thermal.heater_cop)
            sim_temp += (dt / cap_c) * (heat_in - heat_loss)

            # Check boundaries
            sim_soc = sim_energy / capacity if capacity > 0 else 0.0
            if sim_soc <= min_reserve_soc:
                return SurvivalHorizon(
                    hours=round(step_ahead * dt, 2),
                    steps=step_ahead,
                    limiting_factor=LimitingFactor.ENERGY_RESERVE,
                    assumptions="Battery energy projected to breach minimum safe reserve (20%) under conservative life-support load.",
                )
            if sim_temp <= crit_min_temp:
                return SurvivalHorizon(
                    hours=round(step_ahead * dt, 2),
                    steps=step_ahead,
                    limiting_factor=LimitingFactor.LOW_TEMPERATURE,
                    assumptions=f"Internal temperature projected to breach critical low limit ({crit_min_temp}°C).",
                )
            if sim_temp >= crit_max_temp:
                return SurvivalHorizon(
                    hours=round(step_ahead * dt, 2),
                    steps=step_ahead,
                    limiting_factor=LimitingFactor.HIGH_TEMPERATURE,
                    assumptions=f"Internal temperature projected to breach critical high limit ({crit_max_temp}°C).",
                )

        # Survived entire lookahead window
        return SurvivalHorizon(
            hours=round(max_lookahead_steps * dt, 2),
            steps=max_lookahead_steps,
            limiting_factor=LimitingFactor.NONE_WITHIN_HORIZON,
            assumptions=f"Habitat projected safe beyond planning horizon ({max_lookahead_steps * dt:.1f}h).",
        )
