"""AstraGrid safety analysis and survival horizon package."""

from astragrid.safety.survival_horizon import SurvivalHorizonEstimator

__all__ = ["SurvivalHorizonEstimator"]
