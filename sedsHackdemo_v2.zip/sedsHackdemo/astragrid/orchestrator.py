"""Master Simulation and Control Orchestrator for AstraGrid.

Executes the closed-loop rolling-horizon loop, coordinating physics simulation,
fault injection, telemetry estimation, baseline scheduling, safety validation,
and debt ledger accounting.
"""

from __future__ import annotations
import os
from datetime import datetime
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from astragrid.config import HabitatConfig
from astragrid.control.baseline import BaselinePriorityScheduler
from astragrid.control.plan_validator import PlanValidator
from astragrid.faults.manager import FaultManager
from astragrid.faults.models import Fault
from astragrid.models import (
    ControllerAction,
    OperatingMode,
    StateEstimate,
    StructuredEvent,
    SurvivalHorizon,
    Task,
    TruePhysicalState,
)
from astragrid.safety.survival_horizon import SurvivalHorizonEstimator
from astragrid.scenarios.definitions import Scenario
from astragrid.simulator.engine import HabitatSimulator
from astragrid.tasks.debt_ledger import MissionDebtLedger
from astragrid.telemetry.estimator import StateEstimator
from astragrid.telemetry.sensors import TelemetryGenerator


@dataclass
class StepSnapshot:
    """Historical telemetry and decision snapshot for a single simulation step."""
    step: int
    time_hours: float
    true_soc: float
    estimated_soc: float
    soc_confidence: float
    soc_sensors: Dict[str, float]
    solar_gen_kw: float
    total_load_kw: float
    battery_power_kw: float
    habitat_temp_c: float
    heater_power_kw: float
    operating_mode: OperatingMode
    survival_hours: float
    limiting_factor: str
    scheduled_tasks: List[str]
    deferred_tasks: List[str]
    mission_debt_kwh: float
    completed_task_count: int
    action_reason: str
    action_explanation: str
    suspect_sensors: List[str]
    active_fault_names: List[str]


class AstraGridOrchestrator:
    """Coordinates closed-loop execution of AstraGrid."""

    def __init__(self, scenario: Scenario):
        self.scenario = scenario
        self.config = scenario.config

        # 1. Simulator & Telemetry
        self.simulator = HabitatSimulator(self.config)
        self.telemetry_gen = TelemetryGenerator(self.config)
        self.estimator = StateEstimator(self.config)

        # 2. Safety & Management
        self.fault_manager = FaultManager(self.config, list(self.scenario.faults))
        self.ledger = MissionDebtLedger([
            # Deep-copy or fresh instance of tasks
            Task(
                id=t.id,
                name=t.name,
                power_kw=t.power_kw,
                duration_hours=t.duration_hours,
                release_hour=t.release_hour,
                deadline_hour=t.deadline_hour,
                deadline_type=t.deadline_type,
                priority=t.priority,
                mission_value=t.mission_value,
                splittable=t.splittable,
                preemptible=t.preemptible,
            )
            for t in self.scenario.tasks
        ])
        self.survival_estimator = SurvivalHorizonEstimator(self.config)
        self.validator = PlanValidator(self.config)

        # 3. Controller
        self.scheduler = BaselinePriorityScheduler(self.config)

        # 4. State & Logs
        self.current_step = 0
        self.prior_estimate: Optional[StateEstimate] = None
        self.last_commanded_battery_kw: float = 0.0
        self.all_events: List[StructuredEvent] = []
        self.history: List[StepSnapshot] = []
        self.log_file_path: str = os.path.join("logs", "astragrid_audit_trail.log")

        # Initialize audit trail log file on disk
        self._init_log_file()

        # Generate initial state estimate (step 0)
        self._init_step_zero()

    def _init_log_file(self):
        """Ensure logs directory exists and write audit trail session header."""
        try:
            os.makedirs(os.path.dirname(self.log_file_path), exist_ok=True)
            with open(self.log_file_path, "a", encoding="utf-8") as f:
                now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                f.write("\n" + "=" * 90 + "\n")
                f.write(f"  ASTRAGRID AUDIT TRAIL LOG SESSION STARTED: {now_str}\n")
                f.write(f"  Scenario: '{self.scenario.name}' ({self.scenario.scenario_id})\n")
                f.write(f"  Description: {self.scenario.description}\n")
                f.write("=" * 90 + "\n")
        except Exception:
            pass

    def _write_events_to_file(self, events: List[StructuredEvent]):
        """Persist structured events to the audit trail log file."""
        if not events:
            return
        try:
            with open(self.log_file_path, "a", encoding="utf-8") as f:
                now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                for ev in events:
                    f.write(
                        f"[{now_str}] [T+{ev.time_hours:05.2f}h | Step {ev.step:02d}] "
                        f"[{ev.category:<9}] [{ev.severity:<9}] [{ev.source:<15}] "
                        f"{ev.code}: {ev.message}\n"
                    )
        except Exception:
            pass

    def _init_step_zero(self):
        """Initial observation and estimation at t=0."""
        obs = self.telemetry_gen.generate_observation(self.simulator.true_state, self.fault_manager.faults)
        est, evts = self.estimator.estimate_state(obs, None, 0.0)
        self.prior_estimate = est
        self.all_events.extend(evts)
        self._write_events_to_file(evts)

    def add_task(self, task: Task) -> StructuredEvent:
        """Dynamically inject a new mission task with expected energy requirement."""
        time_hours = self.current_step * self.config.simulation.dt_hours
        event = self.ledger.add_task(task, step=self.current_step, time_hours=time_hours)
        self.all_events.append(event)
        self._write_events_to_file([event])
        return event

    def inject_live_fault(self, fault: Fault):
        """Inject a dynamic fault into the running simulation."""
        self.fault_manager.faults.append(fault)
        evt = StructuredEvent(
            step=self.current_step,
            time_hours=self.current_step * self.config.simulation.dt_hours,
            category="FAULT",
            severity="WARNING",
            source="Operator",
            code="LIVE_FAULT_INJECTED",
            message=f"Operator dynamically injected fault '{fault.name}' ({fault.fault_id}).",
            details={"target": fault.target, "severity": fault.severity},
        )
        self.all_events.append(evt)
        self._write_events_to_file([evt])

    def clear_live_faults(self):
        """Clear all active faults immediately."""
        cleared_names = [f.name for f in self.fault_manager.faults if f.is_active]
        for f in self.fault_manager.faults:
            f.is_active = False
            f.duration_steps = 0
        self.fault_manager.faults.clear()
        evt = StructuredEvent(
            step=self.current_step,
            time_hours=self.current_step * self.config.simulation.dt_hours,
            category="FAULT",
            severity="INFO",
            source="Operator",
            code="ALL_FAULTS_CLEARED",
            message=f"Operator cleared all active faults: {', '.join(cleared_names) if cleared_names else 'None'}",
        )
        self.all_events.append(evt)
        self._write_events_to_file([evt])

    def step(self) -> StepSnapshot:
        """Advance one simulation timestep (dt = 15 minutes by default)."""
        step = self.current_step
        dt = self.config.simulation.dt_hours
        time_hours = step * dt

        step_events: List[StructuredEvent] = []

        # 1. Update active faults
        fault_events = self.fault_manager.update_faults(step)
        step_events.extend(fault_events)

        # 2. Hardware telemetry observation (with any sensor noise / telemetry faults)
        observation = self.telemetry_gen.generate_observation(
            self.simulator.true_state,
            self.fault_manager.faults,
        )

        # 3. State estimation without peeking at true state
        estimate, est_events = self.estimator.estimate_state(
            observation,
            self.prior_estimate,
            self.last_commanded_battery_kw,
        )
        step_events.extend(est_events)

        # 4. Operating mode evaluation
        mode, mode_event = self.fault_manager.evaluate_operating_mode(
            step,
            estimate,
            unmet_essential_load_kw=self.simulator.true_state.unmet_load_kw,
        )
        if mode_event:
            step_events.append(mode_event)

        # 5. Survival horizon estimation
        survival = self.survival_estimator.estimate(
            estimate,
            solar_forecast_fn=lambda t: self.simulator.calculate_raw_solar(t),
        )

        # 6. Check task deadlines and feasibility
        deadline_events = self.ledger.check_deadlines_and_feasibility(time_hours, step)
        step_events.extend(deadline_events)

        # 7. Baseline priority scheduling plan
        action, sched_events = self.scheduler.plan_step(
            step,
            time_hours,
            estimate,
            self.ledger,
            mode,
            survival,
        )
        step_events.extend(sched_events)

        # 8. Independent plan validation
        is_valid, validation_errors = self.validator.validate_action(action, estimate)
        if not is_valid:
            # Plan rejected! Fallback to conservative emergency action
            rej_evt = StructuredEvent(
                step=step,
                time_hours=time_hours,
                category="CONTROL",
                severity="EMERGENCY",
                source="PlanValidator",
                code="PLAN_REJECTED",
                message=f"Candidate plan failed independent validation: {'; '.join(validation_errors)}. Applying safe fallback.",
                details={"errors": validation_errors},
            )
            step_events.append(rej_evt)
            # Safe fallback: no tasks, minimal heater, preserve battery
            action = ControllerAction(
                scheduled_task_ids=[],
                deferred_task_ids=[t.id for t in self.ledger.all_tasks() if not t.is_terminal],
                heater_power_kw=1.0,
                curtailed_solar_kw=0.0,
                shed_essential_load_kw=0.0,
                target_battery_power_kw=0.0,
                operating_mode=OperatingMode.EMERGENCY,
                reason_code="VALIDATION_FALLBACK",
                explanation="Applied safe baseline fallback after plan validation failure.",
            )

        # 9. Advance physical simulator with validated action
        active_tasks_running = [
            self.ledger.get_task(t_id)
            for t_id in action.scheduled_task_ids
            if self.ledger.get_task(t_id) is not None
        ]

        next_true_state = self.simulator.step(
            commanded_battery_kw=action.target_battery_power_kw,
            heater_power_kw=action.heater_power_kw,
            active_tasks=active_tasks_running,
            active_faults=self.fault_manager.faults,
        )

        # 10. Update running task progress in Debt Ledger
        for t in active_tasks_running:
            completed, comp_evt = self.ledger.update_task_progress(t.id, dt)
            if comp_evt:
                comp_evt.step = step
                comp_evt.time_hours = time_hours
                step_events.append(comp_evt)

        # Persist all newly generated events to all_events and the audit log file
        self.all_events.extend(step_events)
        self._write_events_to_file(step_events)

        # 11. Record history snapshot
        active_fault_names = [f.name for f in self.fault_manager.faults if f.is_active]
        snapshot = StepSnapshot(
            step=step,
            time_hours=time_hours,
            true_soc=next_true_state.true_soc,
            estimated_soc=estimate.estimated_soc,
            soc_confidence=estimate.soc_confidence,
            soc_sensors=dict(observation.soc_readings),
            solar_gen_kw=next_true_state.solar_generated_kw,
            total_load_kw=next_true_state.essential_load_kw + next_true_state.active_task_load_kw + next_true_state.heater_power_kw,
            battery_power_kw=next_true_state.battery_power_kw,
            habitat_temp_c=next_true_state.habitat_temp_c,
            heater_power_kw=action.heater_power_kw,
            operating_mode=action.operating_mode,
            survival_hours=survival.hours,
            limiting_factor=survival.limiting_factor.value,
            scheduled_tasks=action.scheduled_task_ids,
            deferred_tasks=action.deferred_task_ids,
            mission_debt_kwh=self.ledger.total_mission_debt_kwh,
            completed_task_count=self.ledger.completed_task_count,
            action_reason=action.reason_code,
            action_explanation=action.explanation,
            suspect_sensors=list(estimate.suspect_sensor_ids),
            active_fault_names=active_fault_names,
        )
        self.history.append(snapshot)

        # 12. Advance internal tracking
        self.prior_estimate = estimate
        self.last_commanded_battery_kw = action.target_battery_power_kw
        self.current_step += 1

        return snapshot
