"""Validated configuration models for AstraGrid."""

from __future__ import annotations
from typing import List, Optional
from pydantic import BaseModel, Field, field_validator


class BatteryConfig(BaseModel):
    """Battery electrical parameters."""
    usable_capacity_kwh: float = Field(default=100.0, gt=0, description="Usable battery capacity in kWh")
    initial_soc: float = Field(default=0.85, ge=0.0, le=1.0, description="Initial State of Charge [0, 1]")
    min_reserve_soc: float = Field(default=0.20, ge=0.0, le=1.0, description="Minimum safe reserve SOC [0, 1]")
    critical_min_soc: float = Field(default=0.05, ge=0.0, le=1.0, description="Critical shutdown threshold [0, 1]")
    max_charge_kw: float = Field(default=25.0, gt=0, description="Maximum charge rate in kW")
    max_discharge_kw: float = Field(default=30.0, gt=0, description="Maximum discharge rate in kW")
    charge_efficiency: float = Field(default=0.95, gt=0.0, le=1.0, description="Charging efficiency factor")
    discharge_efficiency: float = Field(default=0.95, gt=0.0, le=1.0, description="Discharging efficiency factor")

    @field_validator("min_reserve_soc")
    @classmethod
    def validate_reserve(cls, v: float, info) -> float:
        critical = info.data.get("critical_min_soc", 0.05)
        if v < critical:
            raise ValueError(f"min_reserve_soc ({v}) must be >= critical_min_soc ({critical})")
        return v


class SolarConfig(BaseModel):
    """Solar power generation parameters."""
    rated_power_kw: float = Field(default=30.0, ge=0, description="Rated peak generation in kW")
    peak_hour: float = Field(default=12.0, ge=0, description="Hour of peak solar generation")
    day_cycle_hours: float = Field(default=24.0, gt=0, description="Length of lunar simulated diurnal cycle")
    noise_std_kw: float = Field(default=0.2, ge=0, description="Gaussian noise std-dev for solar generation")


class ThermalConfig(BaseModel):
    """One-zone habitat thermal parameters."""
    initial_temp_c: float = Field(default=21.0, description="Initial internal habitat temperature in °C")
    min_safe_temp_c: float = Field(default=18.0, description="Minimum normal operating temperature in °C")
    max_safe_temp_c: float = Field(default=24.0, description="Maximum normal operating temperature in °C")
    critical_min_temp_c: float = Field(default=15.0, description="Emergency low temperature threshold in °C")
    critical_max_temp_c: float = Field(default=28.0, description="Emergency high temperature threshold in °C")
    envelope_ua_kw_per_c: float = Field(default=0.15, gt=0, description="Habitat envelope heat loss coefficient UA (kW/°C)")
    thermal_capacity_kwh_per_c: float = Field(default=12.0, gt=0, description="Habitat thermal heat capacity (kWh/°C)")
    heater_max_power_kw: float = Field(default=10.0, ge=0, description="Maximum electrical power of active heater (kW)")
    heater_cop: float = Field(default=1.0, gt=0, description="Coefficient of Performance for heater")
    recoverable_heat_fraction: float = Field(default=0.40, ge=0.0, le=1.0, description="Fraction of electrical load power converted to internal heat")
    default_ext_temp_c: float = Field(default=-20.0, description="Default external environment temperature in °C")


class SimulationConfig(BaseModel):
    """Simulation execution settings."""
    dt_hours: float = Field(default=0.25, gt=0, description="Timestep duration in hours (0.25 = 15 min)")
    total_steps: int = Field(default=96, gt=0, description="Total simulation steps (96 * 0.25h = 24h)")
    horizon_steps: int = Field(default=24, gt=0, description="Lookahead planning horizon in steps (6h)")
    random_seed: int = Field(default=42, description="Random seed for reproducibility")


class EssentialLoadDef(BaseModel):
    """Pre-configured essential load specification."""
    id: str
    name: str
    power_kw: float = Field(gt=0)
    priority: int = 1
    contributes_heat: bool = True


class HabitatConfig(BaseModel):
    """Master habitat system configuration."""
    battery: BatteryConfig = Field(default_factory=BatteryConfig)
    solar: SolarConfig = Field(default_factory=SolarConfig)
    thermal: ThermalConfig = Field(default_factory=ThermalConfig)
    simulation: SimulationConfig = Field(default_factory=SimulationConfig)
    essential_loads: List[EssentialLoadDef] = Field(
        default_factory=lambda: [
            EssentialLoadDef(id="life_support", name="Life Support System (ECLSS)", power_kw=4.5, priority=1),
            EssentialLoadDef(id="comms_primary", name="Primary Lunar Uplink & C&DH", power_kw=1.5, priority=1),
            EssentialLoadDef(id="thermal_pumps", name="Coolant & Thermal Pumps", power_kw=1.0, priority=1),
        ]
    )
