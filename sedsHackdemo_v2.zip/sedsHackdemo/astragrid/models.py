"""Domain models, enums, and data schemas for AstraGrid."""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class OperatingMode(str, Enum):
    """AstraGrid central operational modes."""
    NORMAL = "NORMAL"
    DEGRADED = "DEGRADED"
    EMERGENCY = "EMERGENCY"
    CONTROLLED_SHUTDOWN = "CONTROLLED_SHUTDOWN"
    FAULT = "FAULT"


class DeadlineType(str, Enum):
    """Task deadline classification."""
    HARD = "HARD"
    SOFT = "SOFT"


class TaskStatus(str, Enum):
    """Mission Debt Ledger task lifecycle states."""
    PENDING = "PENDING"
    SCHEDULED = "SCHEDULED"
    DEFERRED = "DEFERRED"
    AT_RISK = "AT_RISK"
    INFEASIBLE_BY_DEADLINE = "INFEASIBLE_BY_DEADLINE"
    COMPLETED = "COMPLETED"
    MISSED_DEADLINE = "MISSED_DEADLINE"
    CANCELLED = "CANCELLED"


class LimitingFactor(str, Enum):
    """Critical boundary identified by survival horizon estimator."""
    ENERGY_RESERVE = "energy_reserve"
    LOW_TEMPERATURE = "low_temperature"
    HIGH_TEMPERATURE = "high_temperature"
    NONE_WITHIN_HORIZON = "none_within_horizon"


class FaultCategory(str, Enum):
    """Categories of injected or detected faults."""
    PHYSICAL_SOLAR = "PHYSICAL_SOLAR"
    PHYSICAL_BATTERY = "PHYSICAL_BATTERY"
    ENVIRONMENTAL = "ENVIRONMENTAL"
    TELEMETRY_SOC_OUTLIER = "TELEMETRY_SOC_OUTLIER"
    TELEMETRY_BIAS = "TELEMETRY_BIAS"


@dataclass
class Task:
    """A mission task requiring power and execution time."""
    id: str
    name: str
    power_kw: float
    duration_hours: float
    release_hour: float
    deadline_hour: float
    deadline_type: DeadlineType = DeadlineType.SOFT
    priority: int = 1  # 1 is highest priority, 10 is lowest
    mission_value: float = 100.0
    splittable: bool = False
    preemptible: bool = True
    
    # Dynamic lifecycle tracking
    status: TaskStatus = TaskStatus.PENDING
    completed_hours: float = 0.0
    energy_consumed_kwh: float = 0.0
    deferral_count: int = 0
    deferral_history: List[Dict[str, Any]] = field(default_factory=list)
    recovery_count: int = 0
    
    @property
    def remaining_hours(self) -> float:
        return max(0.0, self.duration_hours - self.completed_hours)

    @property
    def remaining_energy_kwh(self) -> float:
        return self.remaining_hours * self.power_kw

    @property
    def progress_pct(self) -> float:
        if self.duration_hours <= 0:
            return 100.0
        return min(100.0, (self.completed_hours / self.duration_hours) * 100.0)

    @property
    def is_terminal(self) -> bool:
        return self.status in (
            TaskStatus.COMPLETED,
            TaskStatus.MISSED_DEADLINE,
            TaskStatus.CANCELLED,
            TaskStatus.INFEASIBLE_BY_DEADLINE,
        )


@dataclass
class LoadItem:
    """An electrical load in the habitat."""
    id: str
    name: str
    power_kw: float
    priority: int  # 1 = highest, critical
    is_essential: bool = False
    is_controllable: bool = True
    contributes_heat: bool = True


@dataclass
class TruePhysicalState:
    """Ground truth state of the habitat.
    
    NEVER passed directly to the state estimator or controller!
    Used exclusively by the simulator engine and post-run evaluation.
    """
    step: int
    time_hours: float
    battery_energy_kwh: float
    true_soc: float
    usable_capacity_kwh: float
    max_charge_kw: float
    max_discharge_kw: float
    solar_generated_kw: float
    habitat_temp_c: float
    ext_temp_c: float
    essential_load_kw: float
    active_task_load_kw: float
    heater_power_kw: float
    battery_power_kw: float  # + for charging, - for discharging
    net_surplus_kw: float
    curtailed_power_kw: float
    unmet_load_kw: float
    active_fault_ids: List[str] = field(default_factory=list)


@dataclass
class TelemetryObservation:
    """Observed sensor measurements available to the state estimator."""
    step: int
    time_hours: float
    soc_readings: Dict[str, float]  # sensor_id -> measured SOC (0.0 to 1.0)
    temp_c: float
    solar_kw: float
    total_load_kw: float
    battery_net_power_kw: float  # Commanded / sensed current flow


@dataclass
class StateEstimate:
    """Estimated habitat state computed purely from telemetry and physics."""
    step: int
    time_hours: float
    estimated_soc: float
    soc_confidence: float  # 0.0 to 1.0
    suspect_sensor_ids: List[str]
    estimated_battery_kwh: float
    estimated_temp_c: float
    estimated_solar_kw: float
    estimated_load_kw: float
    estimation_method: str = "MULTI_SENSOR_CONSENSUS"


@dataclass
class ControllerAction:
    """Action chosen by the scheduler for the current timestep."""
    scheduled_task_ids: List[str]
    deferred_task_ids: List[str]
    heater_power_kw: float
    curtailed_solar_kw: float
    shed_essential_load_kw: float
    target_battery_power_kw: float  # + for charge, - for discharge
    operating_mode: OperatingMode
    reason_code: str
    explanation: str


@dataclass
class SurvivalHorizon:
    """Survival margin estimate under conservative policy."""
    hours: float
    steps: int
    limiting_factor: LimitingFactor
    assumptions: str


@dataclass
class StructuredEvent:
    """Structured audit trail record for operational transparency."""
    step: int
    time_hours: float
    category: str  # "CONTROL", "TELEMETRY", "FAULT", "LEDGER", "SAFETY"
    severity: str  # "INFO", "WARNING", "EMERGENCY", "CRITICAL"
    source: str
    code: str
    message: str
    details: Dict[str, Any] = field(default_factory=dict)
