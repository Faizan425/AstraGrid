"""Habitat physical simulation engine for AstraGrid.

Owns and advances the ground-truth physical state of the lunar habitat.
"""

from __future__ import annotations
import math
import random
from typing import Dict, List, Optional
from astragrid.config import HabitatConfig
from astragrid.faults.models import Fault
from astragrid.models import FaultCategory, LoadItem, Task, TruePhysicalState


class HabitatSimulator:
    """Discrete-time physics simulator for solar, battery, thermal, and electrical subsystems."""

    def __init__(self, config: HabitatConfig, essential_loads: Optional[List[LoadItem]] = None):
        self.config = config
        self._rng = random.Random(config.simulation.random_seed)

        # Essential loads
        if essential_loads is not None:
            self.essential_loads = essential_loads
        else:
            self.essential_loads = [
                LoadItem(
                    id=e.id,
                    name=e.name,
                    power_kw=e.power_kw,
                    priority=e.priority,
                    is_essential=True,
                    contributes_heat=e.contributes_heat,
                )
                for e in config.essential_loads
            ]

        # Initial true physical state
        init_energy = config.battery.usable_capacity_kwh * config.battery.initial_soc
        self.true_state = TruePhysicalState(
            step=0,
            time_hours=0.0,
            battery_energy_kwh=init_energy,
            true_soc=config.battery.initial_soc,
            usable_capacity_kwh=config.battery.usable_capacity_kwh,
            max_charge_kw=config.battery.max_charge_kw,
            max_discharge_kw=config.battery.max_discharge_kw,
            solar_generated_kw=0.0,
            habitat_temp_c=config.thermal.initial_temp_c,
            ext_temp_c=config.thermal.default_ext_temp_c,
            essential_load_kw=sum(l.power_kw for l in self.essential_loads),
            active_task_load_kw=0.0,
            heater_power_kw=0.0,
            battery_power_kw=0.0,
            net_surplus_kw=0.0,
            curtailed_power_kw=0.0,
            unmet_load_kw=0.0,
            active_fault_ids=[],
        )

    def calculate_raw_solar(self, time_hours: float) -> float:
        """Calculate un-faulted solar generation based on diurnal solar curve."""
        solar_cfg = self.config.solar
        cycle = solar_cfg.day_cycle_hours
        peak_hr = solar_cfg.peak_hour

        # Sinusoidal daytime curve: positive half-cycle, zero during night
        norm_time = (time_hours % cycle)
        # Assume daytime between (peak_hr - cycle/4) and (peak_hr + cycle/4)
        sun_angle = math.sin(2 * math.pi * (norm_time - (peak_hr - cycle / 4)) / cycle)
        if sun_angle > 0:
            base_gen = solar_cfg.rated_power_kw * sun_angle
        else:
            base_gen = 0.0

        # Add small deterministic noise
        noise = self._rng.gauss(0.0, solar_cfg.noise_std_kw)
        return max(0.0, base_gen + noise)

    def step(
        self,
        commanded_battery_kw: float,  # + for charge, - for discharge
        heater_power_kw: float,
        active_tasks: List[Task],
        active_faults: Optional[List[Fault]] = None,
    ) -> TruePhysicalState:
        """Advance physical state by one discrete timestep (dt_hours)."""
        active_faults = active_faults or []
        dt = self.config.simulation.dt_hours
        step = self.true_state.step
        time_hours = self.true_state.time_hours

        # 1. Evaluate physical fault impacts
        usable_capacity = self.config.battery.usable_capacity_kwh
        max_ch = self.config.battery.max_charge_kw
        max_dis = self.config.battery.max_discharge_kw
        ext_temp = self.config.thermal.default_ext_temp_c
        solar_scale = 1.0

        active_fault_ids = []
        for fault in active_faults:
            if not fault.is_active:
                continue
            active_fault_ids.append(fault.fault_id)
            if fault.category == FaultCategory.PHYSICAL_SOLAR:
                # Severity is multiplier on solar output (e.g., 0.40 = 60% loss)
                solar_scale *= max(0.0, fault.severity)
            elif fault.category == FaultCategory.PHYSICAL_BATTERY:
                if fault.target == "battery_capacity":
                    usable_capacity *= max(0.1, fault.severity)
                elif fault.target == "battery_discharge":
                    max_dis *= max(0.0, fault.severity)
                elif fault.target == "battery_total_failure":
                    usable_capacity = 1.0
                    max_dis = 0.0
                    max_ch = 0.0
            elif fault.category == FaultCategory.ENVIRONMENTAL:
                if fault.target == "external_temp":
                    ext_temp = fault.params.get("ext_temp_c", -50.0)

        # 2. Compute true solar generation
        raw_solar = self.calculate_raw_solar(time_hours)
        true_solar = raw_solar * solar_scale

        # 3. Sum electrical loads
        essential_load = sum(l.power_kw for l in self.essential_loads)
        task_load = sum(t.power_kw for t in active_tasks)
        heater_power = max(0.0, min(self.config.thermal.heater_max_power_kw, heater_power_kw))
        total_demand = essential_load + task_load + heater_power

        # 4. Battery dynamics & power balance
        curr_energy = min(self.true_state.battery_energy_kwh, usable_capacity)
        eff_ch = self.config.battery.charge_efficiency
        eff_dis = self.config.battery.discharge_efficiency

        actual_battery_kw = 0.0
        curtailed_kw = 0.0
        unmet_load_kw = 0.0

        if commanded_battery_kw > 0:
            # Commanded charge: power surplus
            # Limit by battery max charge rate and room remaining in battery
            room_kwh = usable_capacity - curr_energy
            max_charge_by_room = room_kwh / (dt * eff_ch) if (dt * eff_ch) > 0 else 0.0
            actual_charge = min(commanded_battery_kw, max_ch, max_charge_by_room)
            actual_battery_kw = actual_charge
            curr_energy += actual_charge * eff_ch * dt

            # Curtailment if solar > total_demand + actual_charge
            solar_surplus = true_solar - total_demand
            if solar_surplus > actual_charge:
                curtailed_kw = solar_surplus - actual_charge

        elif commanded_battery_kw < 0:
            # Commanded discharge: power deficit
            desired_dis = abs(commanded_battery_kw)
            # Limit by battery max discharge rate and available stored energy
            max_dis_by_energy = (curr_energy * eff_dis) / dt if dt > 0 else 0.0
            actual_dis = min(desired_dis, max_dis, max_dis_by_energy)
            actual_battery_kw = -actual_dis
            curr_energy = max(0.0, curr_energy - (actual_dis / eff_dis) * dt)

            # Check if supply meets total demand
            total_supplied = true_solar + actual_dis
            if total_supplied < total_demand:
                unmet_load_kw = total_demand - total_supplied
        else:
            # Idle battery
            actual_battery_kw = 0.0
            if true_solar < total_demand:
                unmet_load_kw = total_demand - true_solar
            else:
                curtailed_kw = true_solar - total_demand

        # Ensure battery energy stays bounded
        curr_energy = max(0.0, min(curr_energy, usable_capacity))
        true_soc = curr_energy / usable_capacity if usable_capacity > 0 else 0.0

        # 5. Thermal dynamics (one-zone heat balance)
        # heat_loss = UA * (T - T_ext)
        # heat_in = recoverable_fraction * (loads) + COP * heater
        curr_temp = self.true_state.habitat_temp_c
        ua = self.config.thermal.envelope_ua_kw_per_c
        cap_c = self.config.thermal.thermal_capacity_kwh_per_c
        heat_loss = ua * (curr_temp - ext_temp)

        recoverable_elec = self.config.thermal.recoverable_heat_fraction * (essential_load + task_load)
        heater_heat = heater_power * self.config.thermal.heater_cop
        heat_in = recoverable_elec + heater_heat

        temp_next = curr_temp + (dt / cap_c) * (heat_in - heat_loss)

        # 6. Update true state
        next_step = step + 1
        next_time = next_step * dt

        self.true_state = TruePhysicalState(
            step=next_step,
            time_hours=round(next_time, 4),
            battery_energy_kwh=round(curr_energy, 4),
            true_soc=round(true_soc, 4),
            usable_capacity_kwh=round(usable_capacity, 2),
            max_charge_kw=round(max_ch, 2),
            max_discharge_kw=round(max_dis, 2),
            solar_generated_kw=round(true_solar, 2),
            habitat_temp_c=round(temp_next, 2),
            ext_temp_c=round(ext_temp, 2),
            essential_load_kw=round(essential_load, 2),
            active_task_load_kw=round(task_load, 2),
            heater_power_kw=round(heater_power, 2),
            battery_power_kw=round(actual_battery_kw, 2),
            net_surplus_kw=round(true_solar - total_demand, 2),
            curtailed_power_kw=round(curtailed_kw, 2),
            unmet_load_kw=round(unmet_load_kw, 2),
            active_fault_ids=active_fault_ids,
        )
        return self.true_state
