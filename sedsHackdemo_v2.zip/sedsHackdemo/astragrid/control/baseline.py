"""Deterministic Rule-Based Baseline Priority Scheduler for AstraGrid.

Preserves essential life support, protects battery reserve margins, enforces task deadlines,
and manages Mission Debt Ledger transitions with clear causal explanations.
"""

from __future__ import annotations
from typing import List, Tuple
from astragrid.config import HabitatConfig
from astragrid.control.interface import BaseController
from astragrid.models import (
    ControllerAction,
    DeadlineType,
    OperatingMode,
    StateEstimate,
    StructuredEvent,
    SurvivalHorizon,
    Task,
    TaskStatus,
)
from astragrid.tasks.debt_ledger import MissionDebtLedger


class BaselinePriorityScheduler(BaseController):
    """Rule-based priority controller operating strictly on estimated telemetry."""

    def __init__(self, config: HabitatConfig):
        self.config = config

    def plan_step(
        self,
        step: int,
        time_hours: float,
        estimate: StateEstimate,
        ledger: MissionDebtLedger,
        mode: OperatingMode,
        survival_horizon: SurvivalHorizon,
    ) -> Tuple[ControllerAction, List[StructuredEvent]]:
        """Compute baseline rule-based schedule for the current timestep."""
        events: List[StructuredEvent] = []
        dt = self.config.simulation.dt_hours
        capacity = self.config.battery.usable_capacity_kwh
        min_reserve = self.config.battery.min_reserve_soc
        crit_min_soc = self.config.battery.critical_min_soc
        max_ch = self.config.battery.max_charge_kw
        max_dis = self.config.battery.max_discharge_kw
        eff_ch = self.config.battery.charge_efficiency
        eff_dis = self.config.battery.discharge_efficiency

        # 1. Calculate essential electrical load
        essential_demand = sum(e.power_kw for e in self.config.essential_loads)

        # 2. Thermal control: calculate needed heater power to stay inside [18°C, 24°C]
        target_temp = 21.0
        curr_temp = estimate.estimated_temp_c
        ua = self.config.thermal.envelope_ua_kw_per_c
        cap_c = self.config.thermal.thermal_capacity_kwh_per_c
        ext_temp = self.config.thermal.default_ext_temp_c
        heat_loss = ua * (curr_temp - ext_temp)
        recov_heat = self.config.thermal.recoverable_heat_fraction * essential_demand

        heater_power_kw = 0.0
        if curr_temp < self.config.thermal.min_safe_temp_c + 0.5:
            # Need heating
            heat_needed = ((target_temp - curr_temp) * cap_c / dt) + heat_loss - recov_heat
            cop = self.config.thermal.heater_cop
            heater_power_kw = max(
                0.0,
                min(self.config.thermal.heater_max_power_kw, heat_needed / cop if cop > 0 else 0.0),
            )

        base_demand = essential_demand + heater_power_kw
        solar_available = estimate.estimated_solar_kw
        net_margin = solar_available - base_demand

        scheduled_task_ids: List[str] = []
        deferred_task_ids: List[str] = []
        target_battery_power = 0.0
        curtailed_solar = 0.0
        shed_essential_load = 0.0
        reason_code = "NOMINAL_OPERATION"
        explanation = "Essential loads powered; tasks scheduled within safe margins."

        # 3. Retrieve eligible mission tasks
        all_tasks = ledger.all_tasks()
        eligible_tasks: List[Task] = [
            t for t in all_tasks
            if not t.is_terminal and t.release_hour <= time_hours
        ]

        # Sort tasks by priority policy:
        # A. Hard deadline tasks first
        # B. Urgency ratio: (deadline - time) / remaining_duration
        # C. Priority (lower number = higher importance)
        # D. Mission value (higher is better)
        def task_sort_key(t: Task):
            time_left = max(0.01, t.deadline_hour - time_hours)
            urgency = time_left / max(0.01, t.remaining_hours)
            is_hard = 0 if t.deadline_type == DeadlineType.HARD else 1
            return (is_hard, urgency, t.priority, -t.mission_value)

        eligible_tasks.sort(key=task_sort_key)

        # 4. Control Logic: Surplus vs Deficit
        if net_margin >= 0:
            # SOLAR SURPLUS: Solar covers essential loads and heater
            # Headroom check: stop charging if already >= 99.5% full
            if estimate.estimated_soc >= 0.995:
                max_ch_room = 0.0
            else:
                room_kwh = max(0.0, capacity * (1.0 - estimate.estimated_soc))
                max_ch_room = room_kwh / (dt * eff_ch) if (dt * eff_ch) > 0 else 0.0

            # If battery is below safe reserve (20%), prioritize battery charging first!
            if estimate.estimated_soc < min_reserve:
                battery_charge_kw = min(net_margin, max_ch, max_ch_room)
                surplus_for_tasks = net_margin - battery_charge_kw
                reason_code = "RESERVE_RECOVERY"
                explanation = (
                    f"Estimated battery SOC ({estimate.estimated_soc*100:.1f}%) below safe reserve ({min_reserve*100:.0f}%). "
                    "Prioritizing battery recharge; flexible tasks deferred."
                )
                for task in eligible_tasks:
                    deferred_task_ids.append(task.id)
                    deff_evt = ledger.record_deferral(
                        task.id,
                        step,
                        time_hours,
                        f"Battery SOC below safe reserve ({estimate.estimated_soc*100:.1f}% vs {min_reserve*100:.0f}%)",
                        "Policy: Reserve Recovery",
                    )
                    if deff_evt:
                        events.append(deff_evt)
            else:
                # Prompt Rule 5.9.A: Use solar for mandatory loads first, then permitted flexible work, then charging
                surplus_available = net_margin
                for task in eligible_tasks:
                    if surplus_available >= task.power_kw:
                        scheduled_task_ids.append(task.id)
                        surplus_available -= task.power_kw

                        if task.status in (TaskStatus.DEFERRED, TaskStatus.PENDING):
                            rec_evt = ledger.record_recovery(
                                task.id,
                                step,
                                time_hours,
                                f"Solar surplus of {net_margin:.1f} kW available",
                            )
                            if rec_evt:
                                events.append(rec_evt)
                    else:
                        deferred_task_ids.append(task.id)
                        deff_evt = ledger.record_deferral(
                            task.id,
                            step,
                            time_hours,
                            f"Solar surplus ({surplus_available:.2f} kW) insufficient for task power ({task.power_kw:.2f} kW)",
                            "Policy: Surplus Power Constraint",
                        )
                        if deff_evt:
                            events.append(deff_evt)

                # Charge battery with whatever surplus remains after flexible tasks
                battery_charge_kw = min(surplus_available, max_ch, max_ch_room)
                surplus_available -= battery_charge_kw

            target_battery_power = round(battery_charge_kw, 2)
            curtailed_solar = max(0.0, round(surplus_for_tasks if estimate.estimated_soc < min_reserve else surplus_available, 2))

        else:
            # SOLAR DEFICIT: Solar < (essential_demand + heater)
            deficit_kw = abs(net_margin)
            reason_code = "SOLAR_DEFICIT"
            explanation = (
                f"Solar deficit of {deficit_kw:.2f} kW. Discharging battery to protect life support and thermal envelope."
            )

            # Defer all flexible tasks to conserve energy
            for task in eligible_tasks:
                deferred_task_ids.append(task.id)
                deff_evt = ledger.record_deferral(
                    task.id,
                    step,
                    time_hours,
                    f"Solar deficit ({deficit_kw:.2f} kW). Battery discharge restricted to life support.",
                    "Policy: Essential Load Preservation",
                )
                if deff_evt:
                    events.append(deff_evt)

            # Check if battery can cover deficit
            if estimate.estimated_soc <= crit_min_soc:
                # Critical battery emergency!
                reason_code = "CRITICAL_ENERGY_EMERGENCY"
                explanation = (
                    f"CRITICAL: Battery SOC ({estimate.estimated_soc*100:.1f}%) exhausted! "
                    "Shedding loads to prevent uncontrolled habitat collapse."
                )
                target_battery_power = 0.0
                shed_essential_load = min(essential_demand, deficit_kw)
                events.append(
                    StructuredEvent(
                        step=step,
                        time_hours=time_hours,
                        category="SAFETY",
                        severity="CRITICAL",
                        source="BaselineScheduler",
                        code="ESSENTIAL_LOAD_SHEDDING",
                        message=f"CRITICAL DEFICIT: Shedding {shed_essential_load:.2f} kW essential load!",
                        details={"deficit_kw": deficit_kw, "soc": estimate.estimated_soc},
                    )
                )
            else:
                # Discharge battery to support essential loads (cover full base demand if solar is negligible)
                discharge_target = base_demand if solar_available < 0.5 else deficit_kw
                discharge_kw = min(discharge_target, max_dis)
                target_battery_power = -round(discharge_kw, 2)
                if discharge_kw < deficit_kw:
                    shed_essential_load = round(deficit_kw - discharge_kw, 2)

        # Build action
        action = ControllerAction(
            scheduled_task_ids=scheduled_task_ids,
            deferred_task_ids=deferred_task_ids,
            heater_power_kw=round(heater_power_kw, 2),
            curtailed_solar_kw=round(curtailed_solar, 2),
            shed_essential_load_kw=round(shed_essential_load, 2),
            target_battery_power_kw=round(target_battery_power, 2),
            operating_mode=mode,
            reason_code=reason_code,
            explanation=explanation,
        )

        return action, events
