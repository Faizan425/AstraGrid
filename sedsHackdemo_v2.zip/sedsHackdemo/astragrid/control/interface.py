"""Abstract interface for AstraGrid controllers."""

from __future__ import annotations
from abc import ABC, abstractmethod
from typing import List, Tuple
from astragrid.models import ControllerAction, OperatingMode, StateEstimate, StructuredEvent, SurvivalHorizon
from astragrid.tasks.debt_ledger import MissionDebtLedger


class BaseController(ABC):
    """Base class for habitat power and mission task schedulers."""

    @abstractmethod
    def plan_step(
        self,
        step: int,
        time_hours: float,
        estimate: StateEstimate,
        ledger: MissionDebtLedger,
        mode: OperatingMode,
        survival_horizon: SurvivalHorizon,
    ) -> Tuple[ControllerAction, List[StructuredEvent]]:
        """Compute control action for the current simulation step."""
        pass
