"""Independent Plan and Safety Validator for AstraGrid.

Verifies candidate controller decisions before execution without silently mutating values.
"""

from __future__ import annotations
import math
from typing import List, Tuple
from astragrid.config import HabitatConfig
from astragrid.models import ControllerAction, StateEstimate


class PlanValidator:
    """Independent validator checking physical laws, bounds, and reserve compliance."""

    def __init__(self, config: HabitatConfig):
        self.config = config

    def validate_action(
        self,
        action: ControllerAction,
        estimate: StateEstimate,
    ) -> Tuple[bool, List[str]]:
        """Validate candidate controller action.
        
        CRITICAL: Never silently clamp or mutate values! If invalid, return False with errors.
        """
        errors: List[str] = []

        # 1. NaN and infinite checks
        for val_name, val in [
            ("heater_power_kw", action.heater_power_kw),
            ("target_battery_power_kw", action.target_battery_power_kw),
            ("curtailed_solar_kw", action.curtailed_solar_kw),
            ("shed_essential_load_kw", action.shed_essential_load_kw),
        ]:
            if math.isnan(val) or math.isinf(val):
                errors.append(f"Value '{val_name}' is NaN or Infinite ({val}).")

        # 2. Heater bounds check
        if action.heater_power_kw < -1e-4:
            errors.append(f"Negative heater power ({action.heater_power_kw:.2f} kW).")
        if action.heater_power_kw > self.config.thermal.heater_max_power_kw + 1e-4:
            errors.append(
                f"Heater power ({action.heater_power_kw:.2f} kW) exceeds maximum "
                f"({self.config.thermal.heater_max_power_kw:.2f} kW)."
            )

        # 3. Battery rate limits
        if action.target_battery_power_kw > self.config.battery.max_charge_kw + 1e-4:
            errors.append(
                f"Charge rate ({action.target_battery_power_kw:.2f} kW) exceeds maximum "
                f"({self.config.battery.max_charge_kw:.2f} kW)."
            )
        if action.target_battery_power_kw < -self.config.battery.max_discharge_kw - 1e-4:
            errors.append(
                f"Discharge rate ({abs(action.target_battery_power_kw):.2f} kW) exceeds maximum "
                f"({self.config.battery.max_discharge_kw:.2f} kW)."
            )

        # 4. Discharge when battery is empty
        if action.target_battery_power_kw < -1e-4 and estimate.estimated_soc <= 0.001:
            errors.append("Attempted to discharge battery when estimated SOC is at physical zero.")

        # 5. Overcharge check
        if action.target_battery_power_kw > 1e-4 and estimate.estimated_soc >= 0.999:
            errors.append("Attempted to charge battery when estimated SOC is already 100%.")

        is_valid = len(errors) == 0
        return is_valid, errors
