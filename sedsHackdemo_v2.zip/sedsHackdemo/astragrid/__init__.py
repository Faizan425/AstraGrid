"""AstraGrid: Survival-Aware Energy Autonomy & Baseline Mission Scheduler for Lunar Habitats.

A simulation-driven, fault-aware energy-management and mission-scheduling controller
for extreme environments.
"""

__version__ = "1.0.0"
__author__ = "AstraGrid Team"
