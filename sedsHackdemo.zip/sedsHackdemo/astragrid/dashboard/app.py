"""Modern Tkinter Mission Control Dashboard for AstraGrid.

Provides interactive scenario selection, step-by-step or automated simulation,
real-time telemetry gauges, native canvas sparkline graphs, multi-sensor consensus monitoring,
Mission Debt Ledger table, live fault injection, and grounded decision explainer logs.
"""

from __future__ import annotations
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, List, Optional
from astragrid.faults.models import Fault
from astragrid.models import DeadlineType, FaultCategory, OperatingMode, TaskStatus
from astragrid.orchestrator import AstraGridOrchestrator, StepSnapshot
from astragrid.scenarios.definitions import Scenario, get_all_scenarios


class AstraGridDashboard(tk.Tk):
    """Tkinter-based GUI dashboard for AstraGrid baseline scheduler and lunar simulator."""

    def __init__(self):
        super().__init__()

        self.title("AstraGrid — Lunar Habitat Energy Autonomy & Baseline Scheduler")
        self.geometry("1400x880")
        self.minsize(1100, 720)

        # Space Mission Control Color Palette
        self.colors = {
            "bg_dark": "#0c1017",
            "panel_bg": "#151b26",
            "card_bg": "#1c2433",
            "card_border": "#283449",
            "accent_cyan": "#00e5ff",
            "accent_green": "#00e676",
            "accent_amber": "#ffab00",
            "accent_red": "#ff3d00",
            "accent_blue": "#2979ff",
            "accent_purple": "#d500f9",
            "text_bright": "#ffffff",
            "text_normal": "#cfd8dc",
            "text_muted": "#78909c",
            "grid_line": "#263238",
        }

        self.configure(bg=self.colors["bg_dark"])

        # State
        self.scenarios: Dict[str, Scenario] = get_all_scenarios()
        self.selected_scenario_id = tk.StringVar(value="nominal_day")
        self.orchestrator: Optional[AstraGridOrchestrator] = None
        self.is_running = False
        self.run_speed_ms = tk.IntVar(value=200)

        # Style configuration
        self._setup_styles()

        # Build UI layout
        self._build_top_bar()
        self._build_main_content()

        # Initialize simulation
        self.reset_simulation()

    def _setup_styles(self):
        """Configure ttk widgets style."""
        style = ttk.Style(self)
        style.theme_use("clam")

        # Custom combobox and treeview colors
        style.configure(
            "TCombobox",
            fieldbackground=self.colors["card_bg"],
            background=self.colors["panel_bg"],
            foreground=self.colors["text_bright"],
            darkcolor=self.colors["card_border"],
            lightcolor=self.colors["card_border"],
        )
        style.configure(
            "Treeview",
            background=self.colors["card_bg"],
            fieldbackground=self.colors["card_bg"],
            foreground=self.colors["text_normal"],
            rowheight=24,
            font=("Segoe UI", 9),
        )
        style.configure(
            "Treeview.Heading",
            background=self.colors["panel_bg"],
            foreground=self.colors["accent_cyan"],
            font=("Segoe UI", 9, "bold"),
        )
        style.map(
            "Treeview",
            background=[("selected", self.colors["accent_blue"])],
            foreground=[("selected", "#ffffff")],
        )

    def _build_top_bar(self):
        """Top mission control header with scenario selector and simulation playback controls."""
        top_frame = tk.Frame(self, bg=self.colors["panel_bg"], height=64, padx=16, pady=8)
        top_frame.pack(side=tk.TOP, fill=tk.X)

        # Project Brand
        brand_frame = tk.Frame(top_frame, bg=self.colors["panel_bg"])
        brand_frame.pack(side=tk.LEFT, padx=(0, 24))

        tk.Label(
            brand_frame,
            text="ASTRAGRID",
            font=("Segoe UI", 16, "bold"),
            fg=self.colors["accent_cyan"],
            bg=self.colors["panel_bg"],
        ).pack(anchor="w")

        tk.Label(
            brand_frame,
            text="LUNAR SURVIVAL & BASELINE SCHEDULER",
            font=("Segoe UI", 7, "bold"),
            fg=self.colors["text_muted"],
            bg=self.colors["panel_bg"],
        ).pack(anchor="w")

        # Scenario Selector
        scen_frame = tk.Frame(top_frame, bg=self.colors["panel_bg"])
        scen_frame.pack(side=tk.LEFT, padx=(0, 16))

        tk.Label(
            scen_frame,
            text="SCENARIO:",
            font=("Segoe UI", 8, "bold"),
            fg=self.colors["text_muted"],
            bg=self.colors["panel_bg"],
        ).pack(side=tk.LEFT, padx=(0, 6))

        scenario_names = [f"{s_id}: {s.name}" for s_id, s in self.scenarios.items()]
        self.scenario_combo = ttk.Combobox(
            scen_frame,
            values=scenario_names,
            width=36,
            state="readonly",
        )
        self.scenario_combo.current(0)
        self.scenario_combo.bind("<<ComboboxSelected>>", self._on_scenario_selected)
        self.scenario_combo.pack(side=tk.LEFT)

        # Control Buttons
        ctrl_frame = tk.Frame(top_frame, bg=self.colors["panel_bg"])
        ctrl_frame.pack(side=tk.LEFT, padx=(12, 16))

        self.btn_step = tk.Button(
            ctrl_frame,
            text="▶ Step (15m)",
            font=("Segoe UI", 9, "bold"),
            bg="#1976d2",
            fg="#ffffff",
            activebackground="#2196f3",
            activeforeground="#ffffff",
            relief=tk.FLAT,
            padx=10,
            pady=4,
            command=self.step_simulation,
            cursor="hand2",
        )
        self.btn_step.pack(side=tk.LEFT, padx=3)

        self.btn_run = tk.Button(
            ctrl_frame,
            text="⏩ Auto Run",
            font=("Segoe UI", 9, "bold"),
            bg="#2e7d32",
            fg="#ffffff",
            activebackground="#43a047",
            activeforeground="#ffffff",
            relief=tk.FLAT,
            padx=10,
            pady=4,
            command=self.toggle_auto_run,
            cursor="hand2",
        )
        self.btn_run.pack(side=tk.LEFT, padx=3)

        self.btn_step10 = tk.Button(
            ctrl_frame,
            text="+10 Steps",
            font=("Segoe UI", 9),
            bg=self.colors["card_bg"],
            fg=self.colors["text_normal"],
            relief=tk.FLAT,
            padx=8,
            pady=4,
            command=self.step_10_times,
            cursor="hand2",
        )
        self.btn_step10.pack(side=tk.LEFT, padx=3)

        self.btn_reset = tk.Button(
            ctrl_frame,
            text="↺ Reset",
            font=("Segoe UI", 9),
            bg=self.colors["card_bg"],
            fg=self.colors["text_normal"],
            relief=tk.FLAT,
            padx=8,
            pady=4,
            command=self.reset_simulation,
            cursor="hand2",
        )
        self.btn_reset.pack(side=tk.LEFT, padx=3)

        # Speed Slider
        speed_frame = tk.Frame(top_frame, bg=self.colors["panel_bg"])
        speed_frame.pack(side=tk.LEFT, padx=(10, 16))

        tk.Label(
            speed_frame,
            text="SPEED (ms):",
            font=("Segoe UI", 8, "bold"),
            fg=self.colors["text_muted"],
            bg=self.colors["panel_bg"],
        ).pack(side=tk.LEFT, padx=(0, 4))

        speed_scale = tk.Scale(
            speed_frame,
            from_=50,
            to=600,
            orient=tk.HORIZONTAL,
            variable=self.run_speed_ms,
            bg=self.colors["panel_bg"],
            fg=self.colors["text_muted"],
            troughcolor=self.colors["card_bg"],
            highlightthickness=0,
            length=90,
            showvalue=False,
        )
        speed_scale.pack(side=tk.LEFT)

        # Mode Badge (Right)
        self.mode_badge = tk.Label(
            top_frame,
            text="NORMAL",
            font=("Segoe UI", 11, "bold"),
            bg="#1b5e20",
            fg="#ffffff",
            padx=16,
            pady=6,
            relief=tk.RIDGE,
        )
        self.mode_badge.pack(side=tk.RIGHT)

    def _build_main_content(self):
        """Constructs three-column layout: Telemetry Cards, Native Canvas Charts, and Debt Ledger/Logs."""
        main_frame = tk.Frame(self, bg=self.colors["bg_dark"], padx=10, pady=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Left Column: KPI Cards & Live Fault Controls (width: ~340)
        left_col = tk.Frame(main_frame, bg=self.colors["bg_dark"], width=350)
        left_col.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 8))
        left_col.pack_propagate(False)

        self._build_kpi_cards(left_col)
        self._build_sensor_consensus_card(left_col)
        self._build_interactive_fault_card(left_col)

        # Center Column: Canvas Rolling History Graphs (width: ~450)
        center_col = tk.Frame(main_frame, bg=self.colors["bg_dark"])
        center_col.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 8))

        self._build_charts_panel(center_col)

        # Right Column: Mission Debt Ledger & Decision Explainer (width: ~480)
        right_col = tk.Frame(main_frame, bg=self.colors["bg_dark"], width=520)
        right_col.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self._build_debt_ledger_panel(right_col)
        self._build_decision_explainer_panel(right_col)

    def _build_kpi_cards(self, parent: tk.Frame):
        """KPI status cards for battery, solar, thermal, and survival horizon."""
        card = tk.LabelFrame(
            parent,
            text=" CRITICAL TELEMETRY & MARGINS ",
            font=("Segoe UI", 8, "bold"),
            fg=self.colors["accent_cyan"],
            bg=self.colors["card_bg"],
            bd=1,
            relief=tk.SOLID,
            padx=10,
            pady=8,
        )
        card.pack(fill=tk.X, pady=(0, 8))

        # Mission Time
        row1 = tk.Frame(card, bg=self.colors["card_bg"])
        row1.pack(fill=tk.X, pady=2)
        tk.Label(row1, text="MISSION TIME:", font=("Segoe UI", 9, "bold"), fg=self.colors["text_muted"], bg=self.colors["card_bg"]).pack(side=tk.LEFT)
        self.lbl_time = tk.Label(row1, text="T+ 00.00h (Step 0/96)", font=("Segoe UI", 9, "bold"), fg=self.colors["text_bright"], bg=self.colors["card_bg"])
        self.lbl_time.pack(side=tk.RIGHT)

        # Battery SOC
        row2 = tk.Frame(card, bg=self.colors["card_bg"])
        row2.pack(fill=tk.X, pady=2)
        tk.Label(row2, text="BATTERY SOC:", font=("Segoe UI", 9, "bold"), fg=self.colors["text_muted"], bg=self.colors["card_bg"]).pack(side=tk.LEFT)
        self.lbl_soc = tk.Label(row2, text="85.0% (85.0 kWh)", font=("Segoe UI", 10, "bold"), fg=self.colors["accent_green"], bg=self.colors["card_bg"])
        self.lbl_soc.pack(side=tk.RIGHT)

        # Battery Flow
        row_batt = tk.Frame(card, bg=self.colors["card_bg"])
        row_batt.pack(fill=tk.X, pady=2)
        tk.Label(row_batt, text="BATTERY FLOW:", font=("Segoe UI", 9), fg=self.colors["text_muted"], bg=self.colors["card_bg"]).pack(side=tk.LEFT)
        self.lbl_batt_flow = tk.Label(row_batt, text="0.00 kW (IDLE)", font=("Segoe UI", 9), fg=self.colors["text_normal"], bg=self.colors["card_bg"])
        self.lbl_batt_flow.pack(side=tk.RIGHT)

        # Solar Generation
        row3 = tk.Frame(card, bg=self.colors["card_bg"])
        row3.pack(fill=tk.X, pady=2)
        tk.Label(row3, text="SOLAR GENERATION:", font=("Segoe UI", 9), fg=self.colors["text_muted"], bg=self.colors["card_bg"]).pack(side=tk.LEFT)
        self.lbl_solar = tk.Label(row3, text="0.00 kW", font=("Segoe UI", 9, "bold"), fg=self.colors["accent_amber"], bg=self.colors["card_bg"])
        self.lbl_solar.pack(side=tk.RIGHT)

        # Total Habitat Load
        row4 = tk.Frame(card, bg=self.colors["card_bg"])
        row4.pack(fill=tk.X, pady=2)
        tk.Label(row4, text="TOTAL LOAD:", font=("Segoe UI", 9), fg=self.colors["text_muted"], bg=self.colors["card_bg"]).pack(side=tk.LEFT)
        self.lbl_load = tk.Label(row4, text="7.00 kW", font=("Segoe UI", 9), fg=self.colors["text_normal"], bg=self.colors["card_bg"])
        self.lbl_load.pack(side=tk.RIGHT)

        # Habitat Temperature
        row5 = tk.Frame(card, bg=self.colors["card_bg"])
        row5.pack(fill=tk.X, pady=2)
        tk.Label(row5, text="HABITAT TEMP:", font=("Segoe UI", 9), fg=self.colors["text_muted"], bg=self.colors["card_bg"]).pack(side=tk.LEFT)
        self.lbl_temp = tk.Label(row5, text="21.0°C [18-24°C]", font=("Segoe UI", 9, "bold"), fg=self.colors["accent_cyan"], bg=self.colors["card_bg"])
        self.lbl_temp.pack(side=tk.RIGHT)

        # Heater Power
        row_htr = tk.Frame(card, bg=self.colors["card_bg"])
        row_htr.pack(fill=tk.X, pady=2)
        tk.Label(row_htr, text="ACTIVE HEATER:", font=("Segoe UI", 9), fg=self.colors["text_muted"], bg=self.colors["card_bg"]).pack(side=tk.LEFT)
        self.lbl_heater = tk.Label(row_htr, text="0.00 kW", font=("Segoe UI", 9), fg=self.colors["text_normal"], bg=self.colors["card_bg"])
        self.lbl_heater.pack(side=tk.RIGHT)

        # Survival Horizon
        sep = tk.Frame(card, height=1, bg=self.colors["card_border"])
        sep.pack(fill=tk.X, pady=5)

        row6 = tk.Frame(card, bg=self.colors["card_bg"])
        row6.pack(fill=tk.X, pady=2)
        tk.Label(row6, text="SURVIVAL HORIZON:", font=("Segoe UI", 9, "bold"), fg=self.colors["accent_amber"], bg=self.colors["card_bg"]).pack(side=tk.LEFT)
        self.lbl_horizon = tk.Label(row6, text="> 24.0h", font=("Segoe UI", 10, "bold"), fg=self.colors["accent_green"], bg=self.colors["card_bg"])
        self.lbl_horizon.pack(side=tk.RIGHT)

        row7 = tk.Frame(card, bg=self.colors["card_bg"])
        row7.pack(fill=tk.X, pady=2)
        tk.Label(row7, text="LIMITING FACTOR:", font=("Segoe UI", 8), fg=self.colors["text_muted"], bg=self.colors["card_bg"]).pack(side=tk.LEFT)
        self.lbl_limiting = tk.Label(row7, text="none_within_horizon", font=("Segoe UI", 8), fg=self.colors["text_muted"], bg=self.colors["card_bg"])
        self.lbl_limiting.pack(side=tk.RIGHT)

    def _build_sensor_consensus_card(self, parent: tk.Frame):
        """Multi-sensor consensus card for inspecting Byzantine/corrupted telemetry."""
        card = tk.LabelFrame(
            parent,
            text=" TELEMETRY CONSENSUS & VALIDATION ",
            font=("Segoe UI", 8, "bold"),
            fg=self.colors["accent_cyan"],
            bg=self.colors["card_bg"],
            bd=1,
            relief=tk.SOLID,
            padx=10,
            pady=8,
        )
        card.pack(fill=tk.X, pady=(0, 8))

        self.lbl_s1 = tk.Label(card, text="SOC Sensor 1: 85.0% [TRUSTED]", font=("Consolas", 8), fg=self.colors["accent_green"], bg=self.colors["card_bg"], anchor="w")
        self.lbl_s1.pack(fill=tk.X, pady=1)

        self.lbl_s2 = tk.Label(card, text="SOC Sensor 2: 85.0% [TRUSTED]", font=("Consolas", 8), fg=self.colors["accent_green"], bg=self.colors["card_bg"], anchor="w")
        self.lbl_s2.pack(fill=tk.X, pady=1)

        self.lbl_s3 = tk.Label(card, text="SOC Sensor 3: 85.0% [TRUSTED]", font=("Consolas", 8), fg=self.colors["accent_green"], bg=self.colors["card_bg"], anchor="w")
        self.lbl_s3.pack(fill=tk.X, pady=1)

        sep = tk.Frame(card, height=1, bg=self.colors["card_border"])
        sep.pack(fill=tk.X, pady=4)

        row_conf = tk.Frame(card, bg=self.colors["card_bg"])
        row_conf.pack(fill=tk.X)
        tk.Label(row_conf, text="CONFIDENCE:", font=("Segoe UI", 8, "bold"), fg=self.colors["text_muted"], bg=self.colors["card_bg"]).pack(side=tk.LEFT)
        self.lbl_conf = tk.Label(row_conf, text="100%", font=("Segoe UI", 9, "bold"), fg=self.colors["accent_green"], bg=self.colors["card_bg"])
        self.lbl_conf.pack(side=tk.RIGHT)

        self.lbl_suspect = tk.Label(card, text="Isolated Sensors: None", font=("Segoe UI", 8), fg=self.colors["text_muted"], bg=self.colors["card_bg"], anchor="w")
        self.lbl_suspect.pack(fill=tk.X, pady=(2, 0))

    def _build_interactive_fault_card(self, parent: tk.Frame):
        """Live on-the-fly fault injection buttons."""
        card = tk.LabelFrame(
            parent,
            text=" INTERACTIVE FAULT INJECTION ",
            font=("Segoe UI", 8, "bold"),
            fg=self.colors["accent_amber"],
            bg=self.colors["card_bg"],
            bd=1,
            relief=tk.SOLID,
            padx=8,
            pady=8,
        )
        card.pack(fill=tk.X)

        btn_grid = tk.Frame(card, bg=self.colors["card_bg"])
        btn_grid.pack(fill=tk.X)

        tk.Button(
            btn_grid,
            text="⚡ Solar Drop 50%",
            font=("Segoe UI", 8),
            bg="#37474f",
            fg="#ffffff",
            relief=tk.FLAT,
            command=self._inject_live_solar_damage,
            cursor="hand2",
        ).grid(row=0, column=0, sticky="ew", padx=2, pady=2)

        tk.Button(
            btn_grid,
            text="👾 Byzantine Sensor 2",
            font=("Segoe UI", 8),
            bg="#37474f",
            fg="#ffffff",
            relief=tk.FLAT,
            command=self._inject_live_byzantine_sensor,
            cursor="hand2",
        ).grid(row=0, column=1, sticky="ew", padx=2, pady=2)

        tk.Button(
            btn_grid,
            text="🔋 Batt Degrade 50%",
            font=("Segoe UI", 8),
            bg="#37474f",
            fg="#ffffff",
            relief=tk.FLAT,
            command=self._inject_live_battery_fault,
            cursor="hand2",
        ).grid(row=1, column=0, sticky="ew", padx=2, pady=2)

        tk.Button(
            btn_grid,
            text="🧹 Clear All Faults",
            font=("Segoe UI", 8, "bold"),
            bg="#c62828",
            fg="#ffffff",
            relief=tk.FLAT,
            command=self._clear_live_faults,
            cursor="hand2",
        ).grid(row=1, column=1, sticky="ew", padx=2, pady=2)

        btn_grid.columnconfigure(0, weight=1)
        btn_grid.columnconfigure(1, weight=1)

    def _build_charts_panel(self, parent: tk.Frame):
        """Real-time native Canvas sparkline and history charts."""
        box = tk.LabelFrame(
            parent,
            text=" REAL-TIME TELEMETRY CHARTS ",
            font=("Segoe UI", 8, "bold"),
            fg=self.colors["accent_cyan"],
            bg=self.colors["panel_bg"],
            bd=1,
            relief=tk.SOLID,
            padx=8,
            pady=8,
        )
        box.pack(fill=tk.BOTH, expand=True)

        # Chart 1: Battery SOC
        tk.Label(
            box,
            text="BATTERY STATE OF CHARGE (SOC % vs 20% Safe Reserve)",
            font=("Segoe UI", 8, "bold"),
            fg=self.colors["accent_green"],
            bg=self.colors["panel_bg"],
            anchor="w",
        ).pack(fill=tk.X)
        self.canvas_soc = tk.Canvas(box, height=140, bg=self.colors["card_bg"], highlightthickness=0)
        self.canvas_soc.pack(fill=tk.BOTH, expand=True, pady=(2, 8))

        # Chart 2: Power Flows
        tk.Label(
            box,
            text="POWER FLOWS: Solar Generation (kW) vs Total Load (kW)",
            font=("Segoe UI", 8, "bold"),
            fg=self.colors["accent_amber"],
            bg=self.colors["panel_bg"],
            anchor="w",
        ).pack(fill=tk.X)
        self.canvas_power = tk.Canvas(box, height=140, bg=self.colors["card_bg"], highlightthickness=0)
        self.canvas_power.pack(fill=tk.BOTH, expand=True, pady=(2, 8))

        # Chart 3: Temperature
        tk.Label(
            box,
            text="HABITAT TEMPERATURE (°C) vs [18°C, 24°C] Safe Thermal Envelope",
            font=("Segoe UI", 8, "bold"),
            fg=self.colors["accent_cyan"],
            bg=self.colors["panel_bg"],
            anchor="w",
        ).pack(fill=tk.X)
        self.canvas_temp = tk.Canvas(box, height=140, bg=self.colors["card_bg"], highlightthickness=0)
        self.canvas_temp.pack(fill=tk.BOTH, expand=True, pady=(2, 0))

    def _build_debt_ledger_panel(self, parent: tk.Frame):
        """Mission Debt Ledger table showing task lifecycle and backlogs."""
        ledger_frame = tk.LabelFrame(
            parent,
            text=" MISSION DEBT LEDGER (POSTPONED & ENDANGERED WORKLOADS) ",
            font=("Segoe UI", 8, "bold"),
            fg=self.colors["accent_cyan"],
            bg=self.colors["panel_bg"],
            bd=1,
            relief=tk.SOLID,
            padx=8,
            pady=6,
        )
        ledger_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 6))

        # Backlog summary header
        summary_bar = tk.Frame(ledger_frame, bg=self.colors["panel_bg"])
        summary_bar.pack(fill=tk.X, pady=(0, 4))

        self.lbl_debt_backlog = tk.Label(
            summary_bar,
            text="Debt Backlog: 0.0 kWh",
            font=("Segoe UI", 9, "bold"),
            fg=self.colors["accent_amber"],
            bg=self.colors["panel_bg"],
        )
        self.lbl_debt_backlog.pack(side=tk.LEFT)

        self.lbl_tasks_summary = tk.Label(
            summary_bar,
            text="Completed: 0 | Deferred: 0",
            font=("Segoe UI", 9),
            fg=self.colors["text_normal"],
            bg=self.colors["panel_bg"],
        )
        self.lbl_tasks_summary.pack(side=tk.RIGHT)

        # Table columns
        columns = ("id", "name", "power", "deadline", "status", "progress", "deferrals")
        self.tree_tasks = ttk.Treeview(ledger_frame, columns=columns, show="headings", height=5)
        self.tree_tasks.heading("id", text="Task ID")
        self.tree_tasks.heading("name", text="Mission Task")
        self.tree_tasks.heading("power", text="Power (kW)")
        self.tree_tasks.heading("deadline", text="Deadline")
        self.tree_tasks.heading("status", text="Status")
        self.tree_tasks.heading("progress", text="Progress")
        self.tree_tasks.heading("deferrals", text="Deferrals")

        self.tree_tasks.column("id", width=80, anchor="w")
        self.tree_tasks.column("name", width=140, anchor="w")
        self.tree_tasks.column("power", width=65, anchor="center")
        self.tree_tasks.column("deadline", width=70, anchor="center")
        self.tree_tasks.column("status", width=85, anchor="center")
        self.tree_tasks.column("progress", width=65, anchor="center")
        self.tree_tasks.column("deferrals", width=55, anchor="center")

        self.tree_tasks.pack(fill=tk.BOTH, expand=True)

    def _build_decision_explainer_panel(self, parent: tk.Frame):
        """Structured decision explainer and operational event log."""
        log_frame = tk.LabelFrame(
            parent,
            text=" DECISION EXPLAINER & AUDIT TRAIL LOG ",
            font=("Segoe UI", 8, "bold"),
            fg=self.colors["accent_cyan"],
            bg=self.colors["panel_bg"],
            bd=1,
            relief=tk.SOLID,
            padx=8,
            pady=6,
        )
        log_frame.pack(fill=tk.BOTH, expand=True)

        self.txt_events = tk.Text(
            log_frame,
            height=8,
            bg=self.colors["card_bg"],
            fg=self.colors["text_normal"],
            font=("Consolas", 8),
            wrap=tk.WORD,
            bd=0,
            padx=6,
            pady=4,
        )
        self.txt_events.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(log_frame, command=self.txt_events.yview, bg=self.colors["card_bg"])
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.txt_events.config(yscrollcommand=scrollbar.set)

        # Configure colored tags for log output
        self.txt_events.tag_config("INFO", foreground="#81c784")
        self.txt_events.tag_config("WARNING", foreground="#ffd54f")
        self.txt_events.tag_config("EMERGENCY", foreground="#ff8a65")
        self.txt_events.tag_config("CRITICAL", foreground="#ff5252")
        self.txt_events.tag_config("CONTROL", foreground="#4fc3f7")
        self.txt_events.tag_config("LEDGER", foreground="#ba68c8")

    # =========================================================================
    # Simulation Control Handlers
    # =========================================================================

    def _on_scenario_selected(self, event=None):
        """Handle dropdown selection change."""
        sel = self.scenario_combo.get()
        if ":" in sel:
            s_id = sel.split(":", 1)[0].strip()
            self.selected_scenario_id.set(s_id)
            self.reset_simulation()

    def reset_simulation(self):
        """Reset the orchestrator with fresh scenario instances."""
        self.is_running = False
        self.btn_run.config(text="⏩ Auto Run", bg="#2e7d32")

        scenario = self.scenarios[self.selected_scenario_id.get()]
        self.orchestrator = AstraGridOrchestrator(scenario)

        # Clear text log
        self.txt_events.delete("1.0", tk.END)
        self._append_log(
            "INFO",
            f"Initialized scenario '{scenario.name}' ({scenario.scenario_id}). Horizon: 96 steps (24h).",
        )

        self._refresh_ui()

    def step_simulation(self):
        """Advance one 15-minute timestep."""
        if not self.orchestrator:
            return
        if self.orchestrator.current_step >= self.orchestrator.config.simulation.total_steps:
            self._append_log("INFO", "Scenario simulation completed 24-hour horizon.")
            self.is_running = False
            self.btn_run.config(text="⏩ Auto Run", bg="#2e7d32")
            return

        snapshot = self.orchestrator.step()
        self._process_snapshot(snapshot)
        self._refresh_ui()

    def step_10_times(self):
        """Advance 10 timesteps."""
        for _ in range(10):
            if not self.orchestrator:
                break
            if self.orchestrator.current_step >= self.orchestrator.config.simulation.total_steps:
                break
            self.step_simulation()

    def toggle_auto_run(self):
        """Toggle continuous playback."""
        self.is_running = not self.is_running
        if self.is_running:
            self.btn_run.config(text="⏸ Pause", bg="#d84315")
            self._run_loop()
        else:
            self.btn_run.config(text="⏩ Auto Run", bg="#2e7d32")

    def _run_loop(self):
        """Recursive timer callback for auto-run."""
        if not self.is_running:
            return
        if not self.orchestrator or self.orchestrator.current_step >= self.orchestrator.config.simulation.total_steps:
            self.is_running = False
            self.btn_run.config(text="⏩ Auto Run", bg="#2e7d32")
            return

        self.step_simulation()
        self.after(self.run_speed_ms.get(), self._run_loop)

    # =========================================================================
    # Interactive Fault Injections
    # =========================================================================

    def _inject_live_solar_damage(self):
        if not self.orchestrator:
            return
        fault = Fault(
            fault_id=f"live_pv_damage_{self.orchestrator.current_step}",
            category=FaultCategory.PHYSICAL_SOLAR,
            name="Live Solar Loss (50%)",
            target="solar",
            start_step=self.orchestrator.current_step,
            duration_steps=-1,
            severity=0.50,
        )
        self.orchestrator.inject_live_fault(fault)
        self._append_log("WARNING", f"Injected 50% solar panel degradation at step {self.orchestrator.current_step}.")
        self._refresh_ui()

    def _inject_live_byzantine_sensor(self):
        if not self.orchestrator:
            return
        fault = Fault(
            fault_id=f"live_byzantine_s2_{self.orchestrator.current_step}",
            category=FaultCategory.TELEMETRY_SOC_OUTLIER,
            name="Live Byzantine Sensor 2",
            target="sensor_2",
            start_step=self.orchestrator.current_step,
            duration_steps=-1,
            severity=0.85,
            params={"outlier_value": 0.85},
        )
        self.orchestrator.inject_live_fault(fault)
        self._append_log("WARNING", f"Corrupted Sensor 2 to report 85% outlier at step {self.orchestrator.current_step}.")
        self._refresh_ui()

    def _inject_live_battery_fault(self):
        if not self.orchestrator:
            return
        fault = Fault(
            fault_id=f"live_batt_degrade_{self.orchestrator.current_step}",
            category=FaultCategory.PHYSICAL_BATTERY,
            name="Live Battery Degrade (50%)",
            target="battery_capacity",
            start_step=self.orchestrator.current_step,
            duration_steps=-1,
            severity=0.50,
        )
        self.orchestrator.inject_live_fault(fault)
        self._append_log("WARNING", f"Reduced battery usable capacity by 50% at step {self.orchestrator.current_step}.")
        self._refresh_ui()

    def _clear_live_faults(self):
        if not self.orchestrator:
            return
        self.orchestrator.clear_live_faults()
        self._append_log("INFO", "Cleared all active injected faults.")
        self._refresh_ui()

    # =========================================================================
    # UI Refresh & Graph Rendering
    # =========================================================================

    def _process_snapshot(self, snapshot: StepSnapshot):
        """Append newly emitted structured events from orchestrator to event log."""
        if not self.orchestrator:
            return

        # Find recent unprinted events
        recent_events = self.orchestrator.all_events[-10:]
        for ev in recent_events:
            # Avoid reprinting old events
            if ev.step == snapshot.step:
                self._append_log(ev.severity, f"[{ev.source}] {ev.message}")

    def _append_log(self, tag: str, message: str):
        """Write colored entry into event log."""
        self.txt_events.insert(tk.END, f"{message}\n", tag)
        self.txt_events.see(tk.END)

    def _refresh_ui(self):
        """Update KPI values, mode badge, task table, and canvas charts."""
        if not self.orchestrator:
            return

        step = self.orchestrator.current_step
        total_steps = self.orchestrator.config.simulation.total_steps
        time_hours = step * self.orchestrator.config.simulation.dt_hours

        # Get latest state
        true_st = self.orchestrator.simulator.true_state
        est_st = self.orchestrator.prior_estimate

        # Mode Badge
        mode = self.orchestrator.fault_manager.current_mode
        self.mode_badge.config(text=mode.value)
        if mode == OperatingMode.NORMAL:
            self.mode_badge.config(bg="#1b5e20", fg="#ffffff")
        elif mode == OperatingMode.DEGRADED:
            self.mode_badge.config(bg="#f57f17", fg="#ffffff")
        elif mode == OperatingMode.EMERGENCY:
            self.mode_badge.config(bg="#b71c1c", fg="#ffffff")
        elif mode == OperatingMode.CONTROLLED_SHUTDOWN:
            self.mode_badge.config(bg="#4a148c", fg="#ffffff")
        else:
            self.mode_badge.config(bg="#212121", fg="#ffffff")

        # KPI labels
        self.lbl_time.config(text=f"T+ {time_hours:05.2f}h (Step {step}/{total_steps})")

        if est_st:
            soc_pct = est_st.estimated_soc * 100.0
            batt_kwh = est_st.estimated_battery_kwh
            self.lbl_soc.config(text=f"{soc_pct:.1f}% ({batt_kwh:.1f} kWh)")
            if soc_pct < 20.0:
                self.lbl_soc.config(fg=self.colors["accent_red"])
            elif soc_pct < 40.0:
                self.lbl_soc.config(fg=self.colors["accent_amber"])
            else:
                self.lbl_soc.config(fg=self.colors["accent_green"])

            # Battery flow
            flow = true_st.battery_power_kw
            if flow > 0.05:
                self.lbl_batt_flow.config(text=f"+{flow:.2f} kW (CHARGING)", fg=self.colors["accent_green"])
            elif flow < -0.05:
                self.lbl_batt_flow.config(text=f"{flow:.2f} kW (DISCHARGING)", fg=self.colors["accent_amber"])
            else:
                self.lbl_batt_flow.config(text="0.00 kW (IDLE)", fg=self.colors["text_muted"])

            self.lbl_solar.config(text=f"{est_st.estimated_solar_kw:.2f} kW")
            self.lbl_load.config(text=f"{est_st.estimated_load_kw:.2f} kW")
            self.lbl_temp.config(text=f"{est_st.estimated_temp_c:.1f}°C [18-24°C]")
            self.lbl_heater.config(text=f"{true_st.heater_power_kw:.2f} kW")

            # Survival Horizon
            survival = self.orchestrator.survival_estimator.estimate(
                est_st,
                solar_forecast_fn=lambda t: self.orchestrator.simulator.calculate_raw_solar(t),
            )
            self.lbl_horizon.config(text=f"{survival.hours:.1f} hrs")
            if survival.hours < 4.0:
                self.lbl_horizon.config(fg=self.colors["accent_red"])
            elif survival.hours < 12.0:
                self.lbl_horizon.config(fg=self.colors["accent_amber"])
            else:
                self.lbl_horizon.config(fg=self.colors["accent_green"])
            self.lbl_limiting.config(text=survival.limiting_factor.value)

            # Telemetry Consensus Card
            if self.orchestrator.history:
                last_snap = self.orchestrator.history[-1]
                s1_val = last_snap.soc_sensors.get("sensor_1", 0.0)
                s2_val = last_snap.soc_sensors.get("sensor_2", 0.0)
                s3_val = last_snap.soc_sensors.get("sensor_3", 0.0)

                s1_stat = "[ISOLATED]" if "sensor_1" in est_st.suspect_sensor_ids else "[TRUSTED]"
                s2_stat = "[ISOLATED]" if "sensor_2" in est_st.suspect_sensor_ids else "[TRUSTED]"
                s3_stat = "[ISOLATED]" if "sensor_3" in est_st.suspect_sensor_ids else "[TRUSTED]"

                self.lbl_s1.config(
                    text=f"Sensor 1: {s1_val*100:.1f}% {s1_stat}",
                    fg=self.colors["accent_red"] if "sensor_1" in est_st.suspect_sensor_ids else self.colors["accent_green"],
                )
                self.lbl_s2.config(
                    text=f"Sensor 2: {s2_val*100:.1f}% {s2_stat}",
                    fg=self.colors["accent_red"] if "sensor_2" in est_st.suspect_sensor_ids else self.colors["accent_green"],
                )
                self.lbl_s3.config(
                    text=f"Sensor 3: {s3_val*100:.1f}% {s3_stat}",
                    fg=self.colors["accent_red"] if "sensor_3" in est_st.suspect_sensor_ids else self.colors["accent_green"],
                )

                self.lbl_conf.config(text=f"{est_st.soc_confidence*100:.0f}%")
                if est_st.soc_confidence < 0.8:
                    self.lbl_conf.config(fg=self.colors["accent_red"])
                else:
                    self.lbl_conf.config(fg=self.colors["accent_green"])

                suspects = ", ".join(est_st.suspect_sensor_ids) if est_st.suspect_sensor_ids else "None"
                self.lbl_suspect.config(text=f"Isolated Sensors: {suspects}")

        # Update Mission Debt Ledger Table
        self._refresh_tasks_table()

        # Update Native Canvas Charts
        self._redraw_charts()

    def _refresh_tasks_table(self):
        """Update tasks list in Debt Ledger Treeview."""
        for item in self.tree_tasks.get_children():
            self.tree_tasks.delete(item)

        if not self.orchestrator:
            return

        ledger = self.orchestrator.ledger
        self.lbl_debt_backlog.config(text=f"Debt Backlog: {ledger.total_mission_debt_kwh:.1f} kWh")
        self.lbl_tasks_summary.config(
            text=f"Completed: {ledger.completed_task_count} | Deferred: {ledger.deferred_task_count}"
        )

        for task in ledger.all_tasks():
            self.tree_tasks.insert(
                "",
                tk.END,
                values=(
                    task.id,
                    task.name,
                    f"{task.power_kw:.1f}",
                    f"{task.deadline_hour:.1f}h ({task.deadline_type.value})",
                    task.status.value,
                    f"{task.progress_pct:.0f}%",
                    f"{task.deferral_count}",
                ),
            )

    def _redraw_charts(self):
        """Draw telemetry sparkline curves on Tkinter Canvas."""
        history = self.orchestrator.history if self.orchestrator else []
        if not history:
            return

        w_soc = self.canvas_soc.winfo_width() or 400
        h_soc = self.canvas_soc.winfo_height() or 140
        self.canvas_soc.delete("all")

        w_pwr = self.canvas_power.winfo_width() or 400
        h_pwr = self.canvas_power.winfo_height() or 140
        self.canvas_power.delete("all")

        w_tmp = self.canvas_temp.winfo_width() or 400
        h_tmp = self.canvas_temp.winfo_height() or 140
        self.canvas_temp.delete("all")

        max_steps = max(len(history), 96)
        x_step = w_soc / max_steps

        # -------------------------------------------------------------
        # Draw Chart 1: Battery SOC % (0 to 100%)
        # -------------------------------------------------------------
        # 20% safe reserve threshold line
        y_reserve = h_soc - (0.20 * (h_soc - 20) + 10)
        self.canvas_soc.create_line(0, y_reserve, w_soc, y_reserve, fill="#e53935", dash=(4, 4), width=1)
        self.canvas_soc.create_text(w_soc - 80, y_reserve - 8, text="Safe Reserve 20%", fill="#e53935", font=("Segoe UI", 7))

        # 50% grid line
        y_mid = h_soc - (0.50 * (h_soc - 20) + 10)
        self.canvas_soc.create_line(0, y_mid, w_soc, y_mid, fill=self.colors["grid_line"], dash=(2, 4))

        pts_true_soc = []
        pts_est_soc = []
        for i, snap in enumerate(history):
            x = i * x_step
            # SOC scale [0.0, 1.0] -> y in [h-10, 10]
            y_true = h_soc - (snap.true_soc * (h_soc - 20) + 10)
            y_est = h_soc - (snap.estimated_soc * (h_soc - 20) + 10)
            pts_true_soc.append((x, y_true))
            pts_est_soc.append((x, y_est))

        if len(pts_est_soc) > 1:
            # Draw Estimated SOC line (Cyan)
            flat_est = [coord for pt in pts_est_soc for coord in pt]
            self.canvas_soc.create_line(flat_est, fill=self.colors["accent_cyan"], width=2)

        # -------------------------------------------------------------
        # Draw Chart 2: Solar (kW) vs Total Load (kW) (0 to 35 kW)
        # -------------------------------------------------------------
        max_p = 35.0
        pts_solar = []
        pts_load = []
        for i, snap in enumerate(history):
            x = i * x_step
            y_sol = h_pwr - ((snap.solar_gen_kw / max_p) * (h_pwr - 20) + 10)
            y_lod = h_pwr - ((snap.total_load_kw / max_p) * (h_pwr - 20) + 10)
            pts_solar.append((x, y_sol))
            pts_load.append((x, y_lod))

        if len(pts_solar) > 1:
            flat_sol = [coord for pt in pts_solar for coord in pt]
            self.canvas_power.create_line(flat_sol, fill=self.colors["accent_amber"], width=2)

        if len(pts_load) > 1:
            flat_lod = [coord for pt in pts_load for coord in pt]
            self.canvas_power.create_line(flat_lod, fill="#ab47bc", width=2)

        # Legend on power chart
        self.canvas_power.create_text(70, 12, text="― Solar (kW)", fill=self.colors["accent_amber"], font=("Segoe UI", 8, "bold"))
        self.canvas_power.create_text(160, 12, text="― Total Load (kW)", fill="#ab47bc", font=("Segoe UI", 8, "bold"))

        # -------------------------------------------------------------
        # Draw Chart 3: Temperature (°C) [10°C to 30°C]
        # -------------------------------------------------------------
        # 18°C lower bound & 24°C upper bound
        t_min = 10.0
        t_max = 30.0
        t_range = t_max - t_min

        y_18 = h_tmp - (((18.0 - t_min) / t_range) * (h_tmp - 20) + 10)
        y_24 = h_tmp - (((24.0 - t_min) / t_range) * (h_tmp - 20) + 10)
        self.canvas_temp.create_line(0, y_18, w_tmp, y_18, fill="#00e676", dash=(4, 4))
        self.canvas_temp.create_line(0, y_24, w_tmp, y_24, fill="#00e676", dash=(4, 4))
        self.canvas_temp.create_text(w_tmp - 65, y_18 - 8, text="Min Safe 18°C", fill="#00e676", font=("Segoe UI", 7))
        self.canvas_temp.create_text(w_tmp - 65, y_24 - 8, text="Max Safe 24°C", fill="#00e676", font=("Segoe UI", 7))

        pts_temp = []
        for i, snap in enumerate(history):
            x = i * x_step
            clamped_t = max(t_min, min(t_max, snap.habitat_temp_c))
            y_t = h_tmp - (((clamped_t - t_min) / t_range) * (h_tmp - 20) + 10)
            pts_temp.append((x, y_t))

        if len(pts_temp) > 1:
            flat_temp = [coord for pt in pts_temp for coord in pt]
            self.canvas_temp.create_line(flat_temp, fill=self.colors["accent_cyan"], width=2)


def main():
    """Launch AstraGrid Tkinter dashboard."""
    app = AstraGridDashboard()
    app.mainloop()


if __name__ == "__main__":
    main()
