"""AstraGrid Tkinter Dashboard package."""

from astragrid.dashboard.app import AstraGridDashboard, main

__all__ = ["AstraGridDashboard", "main"]
