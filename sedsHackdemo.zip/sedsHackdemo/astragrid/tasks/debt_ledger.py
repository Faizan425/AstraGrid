"""Mission Debt Ledger for AstraGrid.

Tracks postponed, endangered, and recovering mission workloads with strict deadline semantics.
"""

from __future__ import annotations
from typing import Dict, List, Optional, Tuple
from astragrid.models import DeadlineType, StructuredEvent, Task, TaskStatus


class MissionDebtLedger:
    """Manages mission task lifecycle, deferrals, deadline compliance, and backlog metrics."""

    def __init__(self, tasks: Optional[List[Task]] = None):
        self.tasks: Dict[str, Task] = {t.id: t for t in (tasks or [])}
        self.deferral_log: List[Dict] = []

    def get_task(self, task_id: str) -> Optional[Task]:
        return self.tasks.get(task_id)

    def all_tasks(self) -> List[Task]:
        return list(self.tasks.values())

    def update_task_progress(self, task_id: str, dt_hours: float) -> Tuple[bool, Optional[StructuredEvent]]:
        """Advance progress on an executing task."""
        task = self.tasks.get(task_id)
        if not task or task.is_terminal:
            return False, None

        task.completed_hours += dt_hours
        task.energy_consumed_kwh += task.power_kw * dt_hours

        if task.completed_hours >= task.duration_hours - 1e-4:
            task.completed_hours = task.duration_hours
            task.status = TaskStatus.COMPLETED
            event = StructuredEvent(
                step=0,
                time_hours=0.0,
                category="LEDGER",
                severity="INFO",
                source="DebtLedger",
                code="TASK_COMPLETED",
                message=f"Mission task '{task.name}' ({task.id}) successfully COMPLETED.",
                details={"task_id": task.id, "total_energy_kwh": task.energy_consumed_kwh},
            )
            return True, event
        return False, None

    def record_deferral(
        self,
        task_id: str,
        step: int,
        time_hours: float,
        reason: str,
        policy_decision: str,
    ) -> Optional[StructuredEvent]:
        """Record a formal deferral of a mission task."""
        task = self.tasks.get(task_id)
        if not task or task.is_terminal:
            return None

        task.deferral_count += 1
        record = {
            "step": step,
            "time_hours": time_hours,
            "reason": reason,
            "policy": policy_decision,
        }
        task.deferral_history.append(record)
        self.deferral_log.append({"task_id": task_id, **record})

        old_status = task.status
        task.status = TaskStatus.DEFERRED

        return StructuredEvent(
            step=step,
            time_hours=time_hours,
            category="LEDGER",
            severity="WARNING",
            source="DebtLedger",
            code="TASK_DEFERRED",
            message=f"Task '{task.name}' ({task.id}) DEFERRED: {reason} (Deferral #{task.deferral_count})",
            details={
                "task_id": task_id,
                "old_status": old_status.value,
                "deferral_count": task.deferral_count,
                "reason": reason,
            },
        )

    def record_recovery(
        self,
        task_id: str,
        step: int,
        time_hours: float,
        reason: str = "Energy capacity restored",
    ) -> Optional[StructuredEvent]:
        """Record resuming or scheduling a previously deferred task."""
        task = self.tasks.get(task_id)
        if not task or task.is_terminal:
            return None

        task.recovery_count += 1
        task.status = TaskStatus.SCHEDULED

        return StructuredEvent(
            step=step,
            time_hours=time_hours,
            category="LEDGER",
            severity="INFO",
            source="DebtLedger",
            code="TASK_RECOVERED",
            message=f"Deferred task '{task.name}' ({task.id}) RECOVERED into active execution.",
            details={"task_id": task_id, "recovery_count": task.recovery_count, "reason": reason},
        )

    def check_deadlines_and_feasibility(
        self,
        current_time_hours: float,
        step: int,
    ) -> List[StructuredEvent]:
        """Verify task deadlines and feasibility without silently altering hard deadlines."""
        events: List[StructuredEvent] = []

        for task in self.tasks.values():
            if task.is_terminal:
                continue

            time_left = task.deadline_hour - current_time_hours

            # 1. Past deadline check
            if current_time_hours > task.deadline_hour:
                task.status = TaskStatus.MISSED_DEADLINE
                events.append(
                    StructuredEvent(
                        step=step,
                        time_hours=current_time_hours,
                        category="LEDGER",
                        severity="EMERGENCY" if task.deadline_type == DeadlineType.HARD else "WARNING",
                        source="DebtLedger",
                        code="DEADLINE_MISSED",
                        message=(
                            f"Task '{task.name}' ({task.id}) missed its {task.deadline_type.value} "
                            f"deadline at {task.deadline_hour:.1f}h! Completed: {task.progress_pct:.1f}%"
                        ),
                        details={"task_id": task.id, "deadline_hour": task.deadline_hour},
                    )
                )
                continue

            # 2. Hard deadline infeasibility check
            if task.deadline_type == DeadlineType.HARD:
                if time_left < task.remaining_hours:
                    task.status = TaskStatus.INFEASIBLE_BY_DEADLINE
                    events.append(
                        StructuredEvent(
                            step=step,
                            time_hours=current_time_hours,
                            category="LEDGER",
                            severity="CRITICAL",
                            source="DebtLedger",
                            code="TASK_INFEASIBLE_BY_DEADLINE",
                            message=(
                                f"Task '{task.name}' has HARD deadline in {time_left:.2f}h, "
                                f"but needs {task.remaining_hours:.2f}h. Infeasible to finish!"
                            ),
                            details={
                                "task_id": task.id,
                                "time_left_hours": time_left,
                                "remaining_hours": task.remaining_hours,
                            },
                        )
                    )
                elif time_left < task.remaining_hours * 1.25 and task.status == TaskStatus.DEFERRED:
                    # Marginal slack
                    task.status = TaskStatus.AT_RISK
                    events.append(
                        StructuredEvent(
                            step=step,
                            time_hours=current_time_hours,
                            category="LEDGER",
                            severity="WARNING",
                            source="DebtLedger",
                            code="TASK_AT_RISK",
                            message=f"Task '{task.name}' is AT RISK: only {time_left:.2f}h remaining before hard deadline.",
                            details={"task_id": task.id, "time_left_hours": time_left},
                        )
                    )
        return events

    @property
    def total_mission_debt_kwh(self) -> float:
        """Total remaining energy of deferred or at-risk tasks."""
        return sum(
            t.remaining_energy_kwh
            for t in self.tasks.values()
            if t.status in (TaskStatus.DEFERRED, TaskStatus.AT_RISK)
        )

    @property
    def deferred_task_count(self) -> int:
        return sum(1 for t in self.tasks.values() if t.status in (TaskStatus.DEFERRED, TaskStatus.AT_RISK))

    @property
    def completed_task_count(self) -> int:
        return sum(1 for t in self.tasks.values() if t.status == TaskStatus.COMPLETED)
